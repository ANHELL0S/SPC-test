import { z } from 'zod'

const allowedDomains = ['gmail.com', 'mailes.ueb.edu.ec']

const createUsersSchema = z.object({
	username: z
		.string({
			required_error: 'Se requiere nombre de usuario',
		})
		.min(3, 'El nombre debe tener al menos 3 caracteres.'),

	email: z
		.string({
			required_error: 'Correo electrónico es requerido.',
		})
		.email({
			message: 'Correo electrónico inválido.',
		})
		.refine(value => allowedDomains.some(domain => value.endsWith(domain)), {
			message: 'La dirección de correo electronivo no es valida.',
		}),
})

const updateUsersSchema = z.object({
	username: z
		.string({
			required_error: 'Se requiere nombre de usuario',
		})
		.min(3, 'El nombre debe tener al menos 3 caracteres.'),

	email: z
		.string({
			required_error: 'Correo electrónico es requerido.',
		})
		.email({
			message: 'Correo electrónico inválido.',
		})
		.refine(value => allowedDomains.some(domain => value.endsWith(domain)), {
			message: 'El correo electrónico debe ser de Gmail o de mailes.ueb.edu.ec.',
		}),
})

export { createUsersSchema, updateUsersSchema }

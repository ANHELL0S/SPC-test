/* eslint-disable react/prop-types */
import { toast } from 'sonner'
import { useState } from 'react'
import { Modal1 } from '../modal/Modal1'
import { create, update, remove } from '../../services/api/parameter.api'

const ModalCreate = ({ onClose, onCreate }) => {
	const [formData, setFormData] = useState({
		name: '',
	})

	const spanishTranslations = {
		name: 'Nombre del parametro',
	}

	const handleChange = e => {
		const { name, value } = e.target
		setFormData(prevState => ({
			...prevState,
			[name]: value,
		}))
	}

	const handleSubmit = async e => {
		e.preventDefault()

		try {
			const response = await create(formData)
			onClose()
			onCreate()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const modalProps = {
		initialValues: formData,
		translation: spanishTranslations,
		text: {
			title: 'Crear parametro',
			message: 'Por favor, ingresa la información adecuada.',
			submit: 'Ok, Crear!',
			cancel: 'No, Cancelar',
		},
		colors: {
			bg: ['bg-sky-50', 'bg-[#00accf]', 'hover:bg-[#008ec6]'],
		},

		onSubmit: handleSubmit,
		onClose: onClose,
		onChange: handleChange,
	}

	return <Modal1 {...modalProps} />
}

const ModalUpdate = ({ parameter, onClose, onUpdate }) => {
	const [formData, setFormData] = useState({
		name: parameter.name || '',
	})

	const spanishTranslations = {
		name: 'Nombre del parametro',
	}

	const handleChange = e => {
		const { name, value } = e.target
		setFormData(prevState => ({
			...prevState,
			[name]: value,
		}))
	}

	const handleSubmit = async e => {
		e.preventDefault()

		try {
			const updatedFields = { ...formData }

			const response = await update(parameter.id_parameter, updatedFields)
			onClose()
			onUpdate()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const modalProps = {
		initialValues: formData,
		translation: spanishTranslations,
		text: {
			title: 'Actualizar parametro',
			message: 'Por favor, ingresa la información adecuada.',
			submit: 'Si, actualizar!',
			cancel: 'No, cancelar.',
		},
		colors: {
			bg: ['bg-sky-50', 'bg-[#00accf]', 'hover:bg-[#008ec6]'],
		},

		onSubmit: handleSubmit,
		onClose: onClose,
		onChange: handleChange,
	}

	return <Modal1 {...modalProps} />
}

const ModalRemove = ({ parameter, onClose, onRemove }) => {
	const handleRemove = async e => {
		e.preventDefault()
		try {
			const response = await remove(parameter.id_parameter)
			onRemove()
			onClose()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const modalProps = {
		initialValues: '',
		translation: '',
		text: {
			title: 'Eliminar parametro',
			message: `¿Estás seguro que deseas eliminar el parametro ${parameter.name}?`,
			submit: 'Sí, desactivar!',
			cancel: 'No, cancelar',
		},
		colors: {
			title: 'text-[#cd664d]',
			bg: ['bg-[#ede9d0]', 'bg-[#cd664d]', 'hover:bg-[#ac4a33]'],
		},

		onSubmit: handleRemove,
		onClose: onClose,
	}

	return <Modal1 {...modalProps} />
}

export { ModalCreate, ModalUpdate, ModalRemove }

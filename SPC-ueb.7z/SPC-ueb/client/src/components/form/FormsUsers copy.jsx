/* eslint-disable react/prop-types */
import { useState, useEffect } from 'react'
import { fetch, add, update, remove, reactive } from '../../api/users.api'
import { Modal1 } from '../modal/Modal1'
import { toast } from 'sonner'

const useData = () => {
	const [users, setUsers] = useState([])

	useEffect(() => {
		const fetchData = async () => {
			try {
				const data = await fetch()
				setUsers(data)
			} catch (error) {
				console.error('Error fetching tags:', error)
			}
		}

		fetchData()

		return () => {}
	}, [])

	return users
}

const ModalCreate = ({ onClose, onCreate }) => {
	const [formData, setFormData] = useState({
		username: '',
		email: '',
		password: '',
	})

	const spanishTranslations = {
		username: 'Nombre de usuario',
		email: 'Correo electrónico',
		password: 'Contraseña',
	}

	const users = useData()

	const handleChange = e => {
		const { name, value } = e.target
		setFormData(prevState => ({
			...prevState,
			[name]: value,
		}))
	}

	const handleSubmit = async e => {
		e.preventDefault()

		try {
			if (!isFormValid()) {
				toast.error('Por favor, completa todos los campos')
				return
			}

			if (!isValidEmail(formData.email)) {
				toast.error('Por favor, ingresa un correo electrónico válido')
				return
			}

			const existingUser = checkExistingUser(formData)
			if (existingUser) {
				handleExistingErrors(existingUser)
			} else {
				await add(formData)
				onClose()
				onCreate()
			}
		} catch (error) {
			toast.error('Oops! ha ocurrido un error.')
		}
	}

	const checkExistingUser = formData => {
		return users.find(user => user.username === formData.username || user.email === formData.email)
	}

	const handleExistingErrors = existingUser => {
		const errors = {}

		if (existingUser.username === formData.username) {
			errors.username = 'El nombre de usuario ya está en uso'
		}
		if (existingUser.email === formData.email) {
			errors.email = 'El correo electrónico ya está en uso'
		}
		if (errors.username && errors.email) {
			toast.error('El nombre de usuario ya están en uso')
			toast.error('El correo electrónico ya están en uso')
		} else {
			if (errors.username) {
				toast.error(errors.username)
			}

			if (errors.email) {
				toast.error(errors.email)
			}
		}
	}

	const isFormValid = () => {
		return formData.username.trim() !== '' && formData.email.trim() !== ''
	}

	const isValidEmail = email => {
		const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
		return emailPattern.test(email)
	}

	console.log(formData)

	const modalProps = {
		initialValues: formData,
		translation: spanishTranslations,
		text: {
			title: 'Crear Usuario',
			message: 'Por favor, ingresa la información adecuada.',
			submit: 'Ok, Crear!',
			cancel: 'No, Cancelar',
		},
		colors: {
			bg: ['bg-sky-50', 'bg-[#00accf]', 'hover:bg-[#008ec6]'],
		},

		onSubmit: handleSubmit,
		onClose: onClose,
		onChange: handleChange,
	}

	return <Modal1 {...modalProps} />
}

const ModalUpdate = ({ user, onClose, onUpdate }) => {
	const [formData, setFormData] = useState({
		username: user.username || '',
		email: user.email || '',
	})

	const spanishTranslations = {
		username: 'Nombre de usuario',
		email: 'Correo electrónico',
	}

	const users = useData()

	const handleChange = e => {
		const { name, value } = e.target
		setFormData(prevState => ({
			...prevState,
			[name]: value,
		}))
	}

	const handleSubmit = async e => {
		e.preventDefault()

		try {
			const updatedFields = { ...formData }

			if (!isFormModified(updatedFields)) {
				toast.info('No se ha realizado ninguna actualización')
				return
			}

			if (!isFormValid(updatedFields)) {
				toast.error('Por favor, completa todos los campos')
				return
			}

			if (!isValidEmail(updatedFields.email)) {
				toast.error('Por favor, introduce un correo electrónico válido')
				return
			}

			const usernameExists = users.some(u => u.username === updatedFields.username && u.username !== user.username)
			const emailExists = users.some(u => u.email === updatedFields.email && u.email !== user.email)

			if (usernameExists && emailExists) {
				toast.error('El nombre de usuario ya están en uso')
				toast.error('El correo electrónico ya están en uso')
				return
			}

			if (usernameExists) {
				toast.error('El nombre de usuario ya está en uso')
				return
			}

			if (emailExists) {
				toast.error('El correo electrónico ya está en uso')
				return
			}

			await update(user.id, updatedFields)
			onClose()
			onUpdate()
		} catch (error) {
			//console.error('Error updating user:', error.message)
			toast.error('Error updating user')
		}
	}

	const isFormModified = updatedFields => {
		return updatedFields.username !== user.username || updatedFields.email !== user.email
	}

	const isFormValid = formData => {
		return formData.username.trim() !== '' && formData.email.trim() !== ''
	}

	const isValidEmail = email => {
		const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
		return emailPattern.test(email)
	}

	const modalProps = {
		initialValues: formData,
		translation: spanishTranslations,
		text: {
			title: 'Actualizar usuario',
			message: 'Por favor, ingresa la información adecuada.',
			submit: 'Si, actualizar!',
			cancel: 'No, cancelar.',
		},
		colors: {
			bg: ['bg-sky-50', 'bg-[#00accf]', 'hover:bg-[#008ec6]'],
		},

		onSubmit: handleSubmit,
		onClose: onClose,
		onChange: handleChange,
	}

	return <Modal1 {...modalProps} />
}

const ModalRemove = ({ user, onClose, onRemove }) => {
	const handleRemove = async e => {
		e.preventDefault()
		try {
			await remove(user.id)
			onRemove()
			onClose()
		} catch (error) {
			//console.error('Error removing user:', error)
			toast.error('Error removing user')
		}
	}

	const modalProps = {
		initialValues: '',
		translation: '',
		text: {
			title: 'Desactivar usuario',
			message: `¿Estás seguro que deseas desactivar al usuario ${user.username} ?`,
			submit: 'Sí, eliminar',
			cancel: 'No, cancelar',
		},
		colors: {
			title: 'text-[#cd664d]',
			bg: ['bg-[#ede9d0]', 'bg-[#cd664d]', 'hover:bg-[#ac4a33]'],
		},

		onSubmit: handleRemove,
		onClose: onClose,
	}

	return <Modal1 {...modalProps} />
}

const ModalReactive = ({ user, onClose, onReactive }) => {
	const handleReactive = async e => {
		e.preventDefault()
		try {
			await reactive(user.id)
			onClose()
			onReactive()
		} catch (error) {
			//console.error('Error reactivating user:', error)
			toast.error('Error reactivating user')
		}
	}

	const modalProps = {
		initialValues: '',
		translation: '',
		text: {
			title: 'Activar usuario',
			message: `¿Estás seguro que deseas activar al usuario ${user.username} ?`,
			submit: 'Sí, reactivar',
			cancel: 'No, cancelar',
		},
		colors: {
			title: 'text-green-400',
			bg: ['bg-green-50', 'bg-[#45c089]', 'hover:bg-[#008957]'],
		},

		onSubmit: handleReactive,
		onClose: onClose,
	}

	return <Modal1 {...modalProps} />
}

export { ModalCreate, ModalUpdate, ModalRemove, ModalReactive }

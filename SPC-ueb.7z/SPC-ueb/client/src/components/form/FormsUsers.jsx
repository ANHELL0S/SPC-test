/* eslint-disable react/prop-types */
import { toast } from 'sonner'
import { useState } from 'react'
import { Modal1 } from '../modal/Modal1'
import { create, update, remove, reactive } from '../../services/api/users.api'

const ModalCreate = ({ onClose, onCreate }) => {
	const [formData, setFormData] = useState({
		username: '',
		email: '',
	})

	const spanishTranslations = {
		username: 'Nombre de usuario',
		email: 'Correo electrónico',
	}

	const handleChange = e => {
		const { name, value } = e.target
		setFormData(prevState => ({
			...prevState,
			[name]: value,
		}))
	}

	const handleSubmit = async e => {
		e.preventDefault()

		try {
			const response = await create(formData)
			onClose()
			onCreate()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const modalProps = {
		initialValues: formData,
		translation: spanishTranslations,
		text: {
			title: 'Crear Usuario',
			message: 'Por favor, ingresa la información adecuada.',
			submit: 'Ok, Crear!',
			cancel: 'No, Cancelar',
		},
		colors: {
			bg: ['bg-sky-50', 'bg-[#00accf]', 'hover:bg-[#008ec6]'],
		},

		onSubmit: handleSubmit,
		onClose: onClose,
		onChange: handleChange,
	}

	return <Modal1 {...modalProps} />
}

const ModalUpdate = ({ user, onClose, onUpdate }) => {
	const [formData, setFormData] = useState({
		username: user.username || '',
		email: user.email || '',
	})

	const spanishTranslations = {
		username: 'Nombre de usuario',
		email: 'Correo electrónico',
	}

	const handleChange = e => {
		const { name, value } = e.target
		setFormData(prevState => ({
			...prevState,
			[name]: value,
		}))
	}

	const handleSubmit = async e => {
		e.preventDefault()

		try {
			const updatedFields = { ...formData }
			const response = await update(user.id, updatedFields)
			onClose()
			onUpdate()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const modalProps = {
		initialValues: formData,
		translation: spanishTranslations,
		text: {
			title: 'Actualizar usuario',
			message: 'Por favor, ingresa la información adecuada.',
			submit: 'Si, actualizar!',
			cancel: 'No, cancelar.',
		},
		colors: {
			bg: ['bg-sky-50', 'bg-[#00accf]', 'hover:bg-[#008ec6]'],
		},

		onSubmit: handleSubmit,
		onClose: onClose,
		onChange: handleChange,
	}

	return <Modal1 {...modalProps} />
}

const ModalRemove = ({ user, onClose, onRemove }) => {
	const handleRemove = async e => {
		e.preventDefault()
		try {
			const response = await remove(user.id)
			onRemove()
			onClose()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const modalProps = {
		initialValues: '',
		translation: '',
		text: {
			title: 'Desactivar usuario',
			message: `¿Estás seguro que deseas desactivar al usuario ${user.username} ?`,
			submit: 'Sí, eliminar',
			cancel: 'No, cancelar',
		},
		colors: {
			title: 'text-[#cd664d]',
			bg: ['bg-[#ede9d0]', 'bg-[#cd664d]', 'hover:bg-[#ac4a33]'],
		},

		onSubmit: handleRemove,
		onClose: onClose,
	}

	return <Modal1 {...modalProps} />
}

const ModalReactive = ({ user, onClose, onReactive }) => {
	const handleReactive = async e => {
		e.preventDefault()
		try {
			const response = await reactive(user.id)
			onClose()
			onReactive()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const modalProps = {
		initialValues: '',
		translation: '',
		text: {
			title: 'Activar usuario',
			message: `¿Estás seguro que deseas activar al usuario ${user.username} ?`,
			submit: 'Sí, reactivar',
			cancel: 'No, cancelar',
		},
		colors: {
			title: 'text-green-400',
			bg: ['bg-green-50', 'bg-[#45c089]', 'hover:bg-[#008957]'],
		},

		onSubmit: handleReactive,
		onClose: onClose,
	}

	return <Modal1 {...modalProps} />
}

export { ModalCreate, ModalUpdate, ModalRemove, ModalReactive }

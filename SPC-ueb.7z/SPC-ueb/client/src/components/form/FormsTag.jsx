/* eslint-disable react/prop-types */
import { toast } from 'sonner'
import { useState } from 'react'
import { Modal1 } from '../modal/Modal1'
import { create, update, remove, reactive } from '../../services/api/tags.api'

const ModalCreate = ({ onClose, onCreate }) => {
	const [formData, setFormData] = useState({
		name: '',
		description: '',
	})

	const spanishTranslations = {
		name: 'Nombre de la etiqueta',
		description: 'Descripción de la etiqueta',
	}

	const handleChange = e => {
		const { name, value } = e.target
		setFormData(prevState => ({
			...prevState,
			[name]: value,
		}))
	}

	const handleSubmit = async e => {
		e.preventDefault()

		try {
			const response = await create(formData)
			onClose()
			onCreate()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const modalProps = {
		initialValues: formData,
		translation: spanishTranslations,
		text: {
			title: 'Crear Etiqueta',
			message: 'Por favor, ingresa la información adecuada.',
			submit: 'Ok, Crear!',
			cancel: 'No, Cancelar',
		},
		colors: {
			bg: ['bg-sky-50', 'bg-[#00accf]', 'hover:bg-[#008ec6]'],
		},

		onSubmit: handleSubmit,
		onClose: onClose,
		onChange: handleChange,
	}

	return <Modal1 {...modalProps} />
}

const ModalUpdate = ({ tag, onClose, onUpdate }) => {
	const [formData, setFormData] = useState({
		name: tag.name || '',
		description: tag.description || '',
	})

	const spanishTranslations = {
		name: 'Nombre de la etiqueta',
		description: 'Descripción de la etiqueta',
	}

	const handleChange = e => {
		const { name, value } = e.target
		setFormData(prevState => ({
			...prevState,
			[name]: value,
		}))
	}

	const handleSubmit = async e => {
		e.preventDefault()

		try {
			const updatedFields = { ...formData }
			const response = await update(tag.id, updatedFields)
			onClose()
			onUpdate()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const modalProps = {
		initialValues: formData,
		translation: spanishTranslations,
		text: {
			title: 'Actualizar usuario',
			message: 'Por favor, ingresa la información adecuada.',
			submit: 'Si, actualizar!',
			cancel: 'No, cancelar.',
		},
		colors: {
			bg: ['bg-sky-50', 'bg-[#00accf]', 'hover:bg-[#008ec6]'],
		},

		onSubmit: handleSubmit,
		onClose: onClose,
		onChange: handleChange,
	}

	return <Modal1 {...modalProps} />
}

const ModalRemove = ({ tag, onClose, onRemove }) => {
	const handleRemove = async e => {
		e.preventDefault()
		try {
			const response = await remove(tag.id)
			onRemove()
			onClose()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const modalProps = {
		initialValues: '',
		translation: '',
		text: {
			title: 'Desactivar etiqueta',
			message: `¿Estás seguro que deseas desactivar la etiqueta ${tag.name}?`,
			submit: 'Sí, desactivar!',
			cancel: 'No, cancelar',
		},
		colors: {
			title: 'text-[#cd664d]',
			bg: ['bg-[#ede9d0]', 'bg-[#cd664d]', 'hover:bg-[#ac4a33]'],
		},

		onSubmit: handleRemove,
		onClose: onClose,
	}

	return <Modal1 {...modalProps} />
}

const ModalReactive = ({ tag, onClose, onReactive }) => {
	const handleReactive = async e => {
		e.preventDefault()
		try {
			const response = await reactive(tag.id)
			onClose()
			onReactive()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const modalProps = {
		initialValues: '',
		translation: '',
		text: {
			title: 'Reactivar etiqueta',
			message: `¿Estás seguro que deseas reactivar la etiqueta ${tag.name}?`,
			submit: 'Sí, reactivar',
			cancel: 'No, cancelar',
		},
		colors: {
			title: 'text-green-400',
			bg: ['bg-green-50', 'bg-[#45c089]', 'hover:bg-[#008957]'],
		},

		onSubmit: handleReactive,
		onClose: onClose,
	}

	return <Modal1 {...modalProps} />
}

export { ModalCreate, ModalUpdate, ModalRemove, ModalReactive }

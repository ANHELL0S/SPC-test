/* eslint-disable react/prop-types */
import { toast } from 'sonner'
import { useState } from 'react'
import { Modal1 } from '../modal/Modal1'
import { create, update, remove, reactive } from '../../services/api/categories.api'

const ModalCreate = ({ onClose, onCreate }) => {
	const [loading, setLoading] = useState(false)

	const [formData, setFormData] = useState({
		name: '',
		description: '',
	})

	const spanishTranslations = {
		name: 'Nombre de la categoria',
		description: 'Descripción de la categoria',
	}

	const handleChange = e => {
		const { name, value } = e.target
		setFormData(prevState => ({
			...prevState,
			[name]: value,
		}))
	}

	const handleSubmit = async e => {
		e.preventDefault()
		setLoading(true)
		try {
			const response = await create(formData)
			onClose()
			onCreate()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		} finally {
			setLoading(false)
		}
	}

	const modalProps = {
		initialValues: formData,
		translation: spanishTranslations,
		text: {
			title: 'Crear categoria',
			message: '',
			submit: loading ? 'Procesando...' : 'Ok, Crear!',
			cancel: 'No, Cancelar',
		},
		colors: {
			bg: ['bg-sky-50', 'bg-[#00accf]', 'hover:bg-[#008ec6]'],
		},

		loading,
		onClose: onClose,
		onSubmit: handleSubmit,
		onChange: handleChange,
	}

	return <Modal1 {...modalProps} />
}

const ModalUpdate = ({ category, onClose, onUpdate }) => {
	const [loading, setLoading] = useState(false)

	const [formData, setFormData] = useState({
		name: category.name || '',
		description: category.description || '',
	})

	const spanishTranslations = {
		name: 'Nombre de la categoria',
		description: 'Descripción de la categoria',
	}

	const handleChange = e => {
		const { name, value } = e.target
		setFormData(prevState => ({
			...prevState,
			[name]: value,
		}))
	}

	const handleSubmit = async e => {
		e.preventDefault()
		setLoading(true)
		try {
			const updatedFields = { ...formData }

			const response = await update(category.id, updatedFields)
			onClose()
			onUpdate()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		} finally {
			setLoading(false)
		}
	}

	const modalProps = {
		initialValues: formData,
		translation: spanishTranslations,
		text: {
			title: 'Actualizar categoria',
			message: '',
			submit: loading ? 'Procesando...' : 'Si, actualizar!',
			cancel: 'No, cancelar.',
		},
		colors: {
			bg: ['bg-sky-50', 'bg-[#00accf]', 'hover:bg-[#008ec6]'],
		},

		onSubmit: handleSubmit,
		onClose: onClose,
		onChange: handleChange,
		loading,
	}

	return <Modal1 {...modalProps} />
}

const ModalRemove = ({ category, onClose, onRemove }) => {
	const [loading, setLoading] = useState(false)

	const handleRemove = async e => {
		e.preventDefault()
		setLoading(true)
		try {
			const response = await remove(category.id)
			onRemove()
			onClose()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		} finally {
			setLoading(false)
		}
	}

	const modalProps = {
		initialValues: '',
		translation: '',
		text: {
			title: 'Desactivar categoria',
			message: `¿Estás seguro que deseas desactivar la categoria ${category.name}?`,
			submit: loading ? 'Procesando...' : 'Sí, desactivar!',
			cancel: 'No, cancelar',
		},
		colors: {
			title: 'text-[#cd664d]',
			bg: ['bg-[#ede9d0]', 'bg-[#cd664d]', 'hover:bg-[#ac4a33]'],
		},

		loading,
		onClose: onClose,
		onSubmit: handleRemove,
	}

	return <Modal1 {...modalProps} />
}

const ModalReactive = ({ category, onClose, onReactive }) => {
	const [loading, setLoading] = useState(false)

	const handleReactive = async e => {
		e.preventDefault()
		setLoading(true)
		try {
			const response = await reactive(category.id)
			onClose()
			onReactive()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		} finally {
			setLoading(false)
		}
	}

	const modalProps = {
		initialValues: '',
		translation: '',
		text: {
			title: 'Reactivar categoria',
			message: `¿Estás seguro que deseas reactivar la categoria ${category.name}?`,
			submit: loading ? 'Procesando...' : 'Sí, reactivar!',
			cancel: 'No, cancelar',
		},
		colors: {
			title: 'text-green-400',
			bg: ['bg-green-50', 'bg-[#45c089]', 'hover:bg-[#008957]'],
		},

		loading,
		onClose: onClose,
		onSubmit: handleReactive,
	}

	return <Modal1 {...modalProps} />
}

export { ModalCreate, ModalUpdate, ModalRemove, ModalReactive }

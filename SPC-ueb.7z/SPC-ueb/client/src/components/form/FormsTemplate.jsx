import { toast } from 'sonner'
import { Modal1 } from '../modal/Modal1'
import { useState, useEffect } from 'react'
import { ModalSelector } from '../modal/ModalTemplateCreate'
import { fetch as fetchTags } from '../../services/api/tags.api'
import { ModalSelectorUpdate } from '../modal/ModalTemplateUpdate'
import { create, remove, update } from '../../services/api/template.api'
import { fetch as fetchCategory } from '../../services/api/categories.api'

const ModalAdd = ({ onClose, onCreate }) => {
	const [categories, setCategories] = useState([])
	const [tags, setTags] = useState([])
	const [loading, setLoading] = useState(true)

	useEffect(() => {
		const fetchData = async () => {
			try {
				const categoriesResult = await fetchCategory()
				const activeCategories = categoriesResult.filter(category => category.active)

				const tagsResult = await fetchTags()
				const activeTags = tagsResult.filter(tag => tag.active)

				setCategories(activeCategories)
				setTags(activeTags)
				setLoading(false)
			} catch (error) {
				setLoading(false)
			}
		}

		fetchData()
	}, [])

	const handleSubmit = async formData => {
		try {
			const response = await create(formData)
			onCreate()
			onClose()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const translations = {
		title: 'Crear formato',
		message: 'Por favor, seleciona la categoria correcta con sus respectivas etiquetas.',
		submit: 'Ok, añadir!',
		cancel: 'No, cancelar',
	}

	const colors = {
		title: 'text-blue-400',
		bg: ['bg-blue-50', 'bg-blue-400', 'hover:bg-blue-500'],
		submit: ['bg-blue-400', 'bg:blue-400'],
	}

	return (
		<ModalSelector
			translations={translations}
			initialValues={{ categories, tags }}
			onSubmit={handleSubmit}
			onClose={onClose}
			colors={colors}
			loading={loading}
		/>
	)
}

const ModalUpdate = ({ onClose, onUpdate, template }) => {
	const [tagsActive, setTagsActive] = useState([])
	const [loading, setLoading] = useState(true)

	useEffect(() => {
		const fetchData = async () => {
			try {
				const tagsResult = await fetchTags()
				const activeTags = tagsResult.filter(tag => tag.active)
				setTagsActive(activeTags)
				setLoading(false)
			} catch (error) {
				setLoading(false)
			}
		}
		fetchData()
	}, [])

	const handleSubmit = async formData => {
		try {
			const updatedFormData = {
				...formData,
			}

			console.log('Datos del formulario:', updatedFormData) // Log de los datos del formulario
			const response = await update(template.id_template, updatedFormData)
			toast.success(`${response.message}`)
			onUpdate()
			onClose()
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const translations = {
		title: 'Añadir etiquetas',
		message: 'Por favor, añada las etiquetas que sean necesarias.',
		submit: 'Actualizar',
		cancel: 'Cancelar',
	}

	const colors = {
		title: 'text-blue-400',
		bg: ['bg-blue-50', 'bg-blue-400', 'hover:bg-blue-500'],
		submit: ['bg-blue-400', 'bg:blue-400'],
	}

	return (
		<ModalSelectorUpdate
			translations={translations}
			initialValues={tagsActive}
			onSubmit={handleSubmit}
			onClose={onClose}
			colors={colors}
			loading={loading}
			associatedTags={template.tags}
		/>
	)
}

const ModalRemove = ({ template, onClose, onRemove }) => {
	const handleRemove = async e => {
		e.preventDefault()
		try {
			const response = await remove(template.id_template)
			onRemove()
			onClose()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const modalProps = {
		initialValues: '',
		translation: '',
		text: {
			title: 'Eliminar formato',
			message: `¿Estás seguro que deseas eliminar el formato ${template.categoryName} ?`,
			submit: 'Sí, eliminar',
			cancel: 'No, cancelar',
		},
		colors: {
			title: 'text-[#cd664d]',
			bg: ['bg-[#ede9d0]', 'bg-[#cd664d]', 'hover:bg-[#ac4a33]'],
		},

		onSubmit: handleRemove,
		onClose: onClose,
	}

	return <Modal1 {...modalProps} />
}

export { ModalAdd, ModalUpdate, ModalRemove }

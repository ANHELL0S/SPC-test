/* eslint-disable react/prop-types */
import { toast } from 'sonner'
import { Modal1 } from '../modal/Modal1'
import { remove } from '../../services/api/article.api'

const ModalRemove = ({ article, onClose, onRemove }) => {
	const handleRemove = async e => {
		e.preventDefault()
		try {
			const response = await remove(article.id_article)
			onRemove()
			onClose()
			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const modalProps = {
		initialValues: '',
		translation: '',
		text: {
			title: 'Eliminar articulo',
			message: `¿Estás seguro que deseas eliminar el articulo ${article.title}?`,
			submit: 'Sí, eliminar!',
			cancel: 'No, cancelar',
		},
		colors: {
			title: 'text-[#cd664d]',
			bg: ['bg-[#ede9d0]', 'bg-[#cd664d]', 'hover:bg-[#ac4a33]'],
		},

		onSubmit: handleRemove,
		onClose: onClose,
	}

	return <Modal1 {...modalProps} />
}

export { ModalRemove }

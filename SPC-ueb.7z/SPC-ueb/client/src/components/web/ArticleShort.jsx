import { Link } from 'react-router-dom'
import { BiFoodMenu, BiGroup } from 'react-icons/bi'
import { formatDate } from '../../utils/dataFormater.utils'

const ArticleShort = ({ article }) => {
	return (
		<div className='max-w-5xl mx-auto bg-white text-slate-600 w-full'>
			<div className='flex flex-col'>
				<div className='max-w-5xl mx-auto bg-white text-slate-600 w-full'>
					<div className='border-b py-4 px-4 my-6 rounded-lg border border-slate-300'>
						<div className='flex items-center justify-between'>
							<div className='flex items-center text-xs gap-1 pb-2 text-slate-500'>
								<BiFoodMenu />
								<span>{article.category_name}</span>
							</div>

							<div className='flex items-center text-xs gap-1 pb-2 text-slate-500'>
								<span>{formatDate(article.createdAt)}</span>
							</div>
						</div>

						<div>
							<Link to={`/article/${article.id_article}`} className='text-md font-bold hover:underline'>
								{article.title}
							</Link>
						</div>

						<div className='text-sm font-medium text-slate-400 flex items-center gap-1'>
							<BiGroup />
							<h1>{article.author}</h1>
						</div>

						<div className='text-slate-500 flex flex-col text-sm pt-2 gap-y-1 font-medium'>
							<a href={article.link} className='hover:underline text-sky-600 hover:text-sky-800'>
								{article.link}
							</a>
						</div>

						<div className='flex flex-col gap-y-2 text-sm my-4 font-medium text-slate-400'>
							<p>{article.summary.length > 250 ? article.summary.substring(0, 250) + '...' : article.summary}</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export { ArticleShort }

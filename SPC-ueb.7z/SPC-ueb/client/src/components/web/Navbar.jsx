import { Link } from 'react-router-dom'
import { useConfigData } from '../../hooks/useConfig'

const Navbar = () => {
	const config = useConfigData()

	return (
		<navbar className='z-10 bg-transparent text-neutral-500 lg:px-0 h-16 flex items-center justify-between'>
			<div className='flex items-center'>
				<Link to='/'>
					<div className='flex flex-row items-center bg-slate-700 rounded-sm'>
						<h1 className='text-slate-50 font-bold text-lg px-2 rounded-md'>SPC</h1>

						<span className='bg-slate-100 text-slate-700 px-2 font-semibold text-lg'>
							{config.abbreviation ? config.abbreviation : ''}
						</span>
					</div>
				</Link>
			</div>

			<Link
				to='/login'
				className='lg:flex space-x-6 text-slate-500 text-sm font-medium hover:text-[#f68d7a] border-b-2 hover:border-[#f68d7a] transition duration-150 ease-in-out'>
				Iniciar sesión
			</Link>
		</navbar>
	)
}

export { Navbar }

import { useState } from 'react'
import { formatDate } from '../../utils/dataFormater.utils'
import { BiCalendarAlt, BiMessageSquareDetail, BiBookmark, BiPlus, BiX } from 'react-icons/bi'
import { ButtonLoadingSpinner } from '../ui/ButtomSpinner'

const ArticleDetails = ({
	article,
	comments,
	isAuthenticated,
	isInCollection,
	handleAddCollectionArticle,
	handleRemoveCollectionArticle,
	totalArticlesInCollection,
}) => {
	const [isLoading, setIsLoading] = useState(false)

	const handleClick = async () => {
		setIsLoading(true)
		if (isInCollection) {
			await handleRemoveCollectionArticle()
		} else {
			await handleAddCollectionArticle()
		}
		setIsLoading(false)
	}

	return (
		<div className='max-w-5xl mx-auto bg-white text-slate-600 w-full'>
			<div className='flex flex-col'>
				<div className='max-w-5xl mx-auto bg-white text-slate-600 w-full'>
					<div className='border-b py-4 px-4 my-6 rounded-lg border border-slate-300'>
						<div className='flex items-center justify-between'>
							<div>
								<div className='flex items-center text-xs gap-1 pb-2 text-slate-500'>
									<BiCalendarAlt />
									<span>{formatDate(article.createdAt)}</span>
								</div>
							</div>
						</div>

						<div>
							<h1 className='text-sm font-medium text-slate-400'>Autor: {article.author}</h1>
						</div>

						<div>
							<h1 className='text-md font-bold'>{article.author}</h1>
						</div>

						<div className='text-slate-500 flex flex-col text-sm pt-2 gap-y-1 font-medium'>
							<a href={article.link} className='hover:underline text-sky-600 hover:text-sky-800'>
								{article.link}
							</a>
						</div>

						<div className='flex flex-col gap-y-2 text-xs my-4 font-medium'>
							<p className='font-normal text-sm'>{article.summary}</p>
						</div>

						<hr className='border-1 border-neutral-300' />

						<div className='flex flex-col gap-y-2 text-xs my-4 font-medium'>
							<h2 className='font-semibold text-slate-600'>Datos del artículo</h2>
							{article.tags.map(tag => (
								<span key={tag.id_relation_tag_article} className='font-normal'>
									{tag.name_tag}: {tag.description_tag}
								</span>
							))}

							{article.parameters.map(parameter => (
								<span key={parameter.id_relation_parameter_article} className='font-normal'>
									{parameter.name_parameter}: {parameter.description_parameter}
								</span>
							))}
						</div>

						<div className='flex items-center justify-between'>
							<div className='flex items-center space-x-4 text-sm'>
								<div className='flex flex-row items-center justify-center gap-1'>
									<BiMessageSquareDetail className='inline-block text-slate-400' />
									<span className='font-medium text-slate-500'>{comments.length}</span>
								</div>

								<div className='flex flex-row items-center justify-center gap-1'>
									<BiBookmark className='inline-block text-slate-400' />
									<span className='font-medium text-slate-500'>{totalArticlesInCollection}</span>
								</div>
							</div>

							{isAuthenticated && (
								<button
									onClick={handleClick}
									disabled={isLoading}
									className={`text-xs font-semibold ${
										isInCollection
											? 'text-red-500 bg-red-50 border border-red-300 hover:bg-red-100'
											: 'text-slate-500 bg-slate-50 border border-slate-300 hover:bg-slate-100'
									} rounded-full px-4 py-1.5 focus:outline-none transition-colors duration-150`}>
									{isInCollection ? (
										<div className='flex flex-row gap-1 items-center'>
											{isLoading ? (
												<ButtonLoadingSpinner loadingText='Eliminando...' textColor='text-red-400' />
											) : (
												<>
													<BiX className='text-lg' />
													<span>Eliminar de colección</span>
												</>
											)}
										</div>
									) : (
										<div className='flex flex-row gap-1 items-center'>
											{isLoading ? (
												<ButtonLoadingSpinner loadingText='Añadiendo...' textColor='text-slate-400' />
											) : (
												<>
													<BiPlus className='text-lg' />
													<span>Añadir a colección</span>
												</>
											)}
										</div>
									)}
								</button>
							)}
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export { ArticleDetails }

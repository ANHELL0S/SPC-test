import { useState, useEffect } from 'react'
import { HiMiniCheckCircle, HiXMark } from 'react-icons/hi2'

const Modal1 = ({ initialValues, text, colors, onSubmit, onClose, onChange, translation, validationMessages }) => {
	const [modalOpen, setModalOpen] = useState(false)
	const [errors, setErrors] = useState({})
	const [inputValidity, setInputValidity] = useState({})

	useEffect(() => {
		setModalOpen(true)
	}, [])

	useEffect(() => {
		const timer = setTimeout(clearErrors, 3000)
		return () => clearTimeout(timer)
	}, [errors])

	const handleChange = e => {
		const { name, value } = e.target
		onChange(e)
		const fieldErrors = validateField(name, value)
		setErrors(prevErrors => ({
			...prevErrors,
			[name]: fieldErrors,
		}))
		setInputValidity(prevInputValidity => ({
			...prevInputValidity,
			[name]: !fieldErrors,
		}))
	}

	const validateField = (name, value) => {
		let fieldErrors = ''
		// Example validation, modify as needed
		if (!value.trim()) {
			fieldErrors = 'Este campo es requerido'
		}
		return fieldErrors
	}

	const handleSubmit = async e => {
		e.preventDefault()
		const formErrors = validateForm(initialValues)
		if (Object.keys(formErrors).length > 0) {
			setErrors(formErrors)
		} else {
			setErrors({})
			onSubmit(e)
		}
	}

	const validateForm = values => {
		const errors = {}
		for (const [key, value] of Object.entries(values)) {
			const fieldErrors = validateField(key, value)
			if (fieldErrors) {
				errors[key] = fieldErrors
			}
		}
		return errors
	}

	const clearErrors = () => {
		setErrors({})
	}

	return (
		<div
			className={`fixed inset-0 flex items-center justify-center z-50 bg-neutral-50 transition-opacity ${
				modalOpen ? 'opacity-100' : 'opacity-0'
			}`}>
			<div className={`modal w-auto transition-opacity`}>
				<div
					className={`flex items-center justify-between gap-2 text-md text-neutral-500 font-medium border border-neutral-300 pl-4`}>
					<span>{text.title}</span>
					<button
						type='button'
						onClick={onClose}
						className={`flex flex-row items-center py-2 px-4 text-neutral-600 hover:text-neutral-50 bg-neutral-50 ${colors.bg[2]} border-l border-neutral-300 transition-colors duration-200`}>
						<HiXMark />
					</button>
				</div>

				<p className='px-4 text-neutral-400 font-medium text-sm text-center py-6'>{text.message}</p>

				<form onSubmit={handleSubmit} className='space-y-3 w-auto'>
					{Object.keys(initialValues).map(key => (
						<div key={key} className='flex flex-col relative w-auto'>
							<div className='flex items-center'>
								<div className='flex flex-col w-full gap-1 pb-2'>
									<label className={`text-neutral-500 font-medium ${errors[key] ? 'text-red-500' : ''}`}>
										{translation[key]}
									</label>

									<div className='relative flex items-center'>
										<input
											type='text'
											name={key}
											value={initialValues[key]}
											onChange={handleChange}
											className={`flex-1 border border-neutral-200 py-1 px-4 focus:outline-none focus:border-neutral-300 text-neutral-600 bg-neutral-50 ${
												errors[key] ? 'border-red-500' : ''
											}`}
										/>
									</div>
								</div>
							</div>
							{errors[key] && <p className='text-red-500 text-sm font-medium'>{errors[key]}</p>}
						</div>
					))}

					<div className='flex flex-col gap-2 text-md my-2 text-neutral-500 pt-4'>
						<button
							type='submit'
							className={`${colors.bg[1]} ${colors.bg[2]} text-sm text-neutral-50 py-1.5 transition-colors duration-200 focus:outline-none`}>
							<span className='text-sm'>{text.submit}</span>
						</button>
					</div>
				</form>
			</div>
		</div>
	)
}

export { Modal1 }

import { useState, useEffect } from 'react'
import { BiInfoCircle } from 'react-icons/bi'
import { HiMiniCheckCircle, HiXMark } from 'react-icons/hi2'

const Modal1 = ({ initialValues, text, onSubmit, onClose, onChange, translation, loading }) => {
	const [modalOpen, setModalOpen] = useState(false)
	const [errors, setErrors] = useState({})
	const [inputValidity, setInputValidity] = useState({})

	useEffect(() => {
		setModalOpen(true)
	}, [])

	useEffect(() => {
		const timer = setTimeout(clearErrors, 3000)
		return () => clearTimeout(timer)
	}, [errors])

	const handleChange = e => {
		const { name, value } = e.target
		onChange(e)
		const fieldErrors = validateField(name, value)
		setErrors(prevErrors => ({
			...prevErrors,
			[name]: fieldErrors,
		}))
		setInputValidity(prevInputValidity => ({
			...prevInputValidity,
			[name]: !fieldErrors,
		}))
	}

	const validateField = (name, value) => {
		let fieldErrors = ''
		if (!value.trim()) {
			fieldErrors = 'Este campo es requerido'
		}
		return fieldErrors
	}

	const handleSubmit = async e => {
		e.preventDefault()
		const formErrors = validateForm(initialValues)
		if (Object.keys(formErrors).length > 0) {
			setErrors(formErrors)
		} else {
			setErrors({})
			onSubmit(e)
		}
	}

	const validateForm = values => {
		const errors = {}
		for (const [key, value] of Object.entries(values)) {
			const fieldErrors = validateField(key, value)
			if (fieldErrors) {
				errors[key] = fieldErrors
			}
		}
		return errors
	}

	const clearErrors = () => {
		setErrors({})
	}

	return (
		<div
			className={`fixed inset-0 flex items-center justify-center z-50 bg-neutral-50 transition-opacity ${
				modalOpen ? 'opacity-100' : 'opacity-0'
			}`}>
			<div
				className={`modal w-full max-w-md bg-white shadow-lg rounded-lg transition-all transform ${
					modalOpen ? 'scale-100' : 'scale-95'
				}`}>
				<div className='flex items-center justify-between gap-2 text-md text-neutral-500 font-medium border-b border-neutral-200 px-4 py-2 rounded-t-lg'>
					<span>{text.title}</span>
					<button
						type='button'
						onClick={onClose}
						className='flex items-center p-2 rounded-full text-neutral-400 hover:text-neutral-700 transition-colors hover:bg-neutral-100'>
						<HiXMark className='w-5 h-5' />
					</button>
				</div>

				<div className='flex items-center justify-center gap-1 text-neutral-500 py-4 px-4 text-md mx-4'>
					<p>{text.message}</p>
				</div>

				<form onSubmit={handleSubmit} className='space-y-2 px-4 pb-6'>
					{Object.keys(initialValues).map(key => (
						<div key={key} className='flex flex-col'>
							<label className={`text-sm font-medium text-neutral-500 ${errors[key] ? 'text-red-500' : ''}`}>
								{translation[key]}
							</label>
							<input
								type='text'
								name={key}
								value={initialValues[key]}
								onChange={handleChange}
								className={`text-neutral-600 mt-1 block w-full px-3 py-1.5 border border-neutral-300 rounded-md shadow-sm focus:outline-none focus:ring ${
									errors[key] ? 'border-red-500 focus:ring-red-300' : 'focus:ring-blue-300'
								}`}
							/>
							{errors[key] && <p className='mt-1 text-xs text-red-500'>{errors[key]}</p>}
						</div>
					))}

					<div className='flex justify-end space-x-2 pt-4'>
						<button
							type='button'
							onClick={onClose}
							className='px-4 py-2 text-sm font-medium text-neutral-400 hover:text-neutral-600 border rounded-md hover:bg-neutral-100 transition-colors'>
							{text.cancel}
						</button>

						<button
							type='submit'
							disabled={loading}
							className={`px-4 py-2 text-sm font-medium text-white rounded-md focus:outline-none transition-colors ${
								loading ? 'bg-blue-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
							}`}>
							{text.submit}
						</button>
					</div>
				</form>
			</div>
		</div>
	)
}

export { Modal1 }

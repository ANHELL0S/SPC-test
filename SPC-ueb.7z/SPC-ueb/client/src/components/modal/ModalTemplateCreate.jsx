import React, { useEffect, useState } from 'react'
import { BiListUl, BiX } from 'react-icons/bi'

const ModalSelector = ({ initialValues, onSubmit, onClose, translations, colors }) => {
	const [selectedCategory, setSelectedCategory] = useState(null)
	const [selectedTags, setSelectedTags] = useState([])
	const [filteredCategories, setFilteredCategories] = useState([])
	const [filteredTags, setFilteredTags] = useState([])
	const [selectedTagsBadgets, setSelectedTagsBadgets] = useState([])
	const [modalOpen, setModalOpen] = useState(false)

	useEffect(() => {
		setModalOpen(true)
	}, [])

	useEffect(() => {
		setFilteredCategories(initialValues.categories)
		setFilteredTags(initialValues.tags)
	}, [initialValues])

	const handleCategoryChange = e => {
		const selectedCategoryId = e.target.value
		setSelectedCategory(selectedCategoryId)
	}

	const handleTagChange = e => {
		const selectedTagIds = Array.from(e.target.selectedOptions, option => option.value)
		const uniqueSelectedTagIds = Array.from(new Set(selectedTagIds)) // Eliminar duplicados

		// Verificar si el tag ya está seleccionado antes de agregarlo
		const newTags = uniqueSelectedTagIds.filter(tagId => !selectedTags.includes(tagId))
		setSelectedTags(prevTags => [...prevTags, ...newTags])

		// Filtrar los nuevos tags seleccionados
		const selectedTagsData = initialValues.tags.filter(tag => newTags.includes(tag.id_tag))
		setSelectedTagsBadgets(prevBadgets => [...prevBadgets, ...selectedTagsData])
	}

	const handleRemoveBadget = tagId => {
		setSelectedTags(prevTags => prevTags.filter(id => id !== tagId))
		setSelectedTagsBadgets(prevBadgets => prevBadgets.filter(tag => tag.id_tag !== tagId))
	}

	const handleSubmit = e => {
		e.preventDefault()
		const formData = {
			id_category: selectedCategory,
			id_tag: selectedTags,
		}
		onSubmit(formData) // Llamar a la función de callback con los datos del formulario
	}

	return (
		<>
			<div
				className={`fixed inset-0 flex items-center justify-center z-50 bg-neutral-50 transition-opacity ${
					modalOpen ? 'opacity-100' : 'opacity-0'
				}`}>
				<div className={`modal w-auto transition-opacity`}>
					<div
						className={`flex items-center justify-between gap-2 text-md text-neutral-500 font-medium border border-neutral-300 pl-4`}>
						<span className='flex flex-row items-center'>
							<span>{translations.title}</span>
						</span>

						<button
							type='button'
							onClick={onClose}
							className={`flex flex-row items-center py-2 px-4 text-neutral-600 hover:text-neutral-50 bg-neutral-50 ${colors.bg[2]} border-l border-neutral-300 transition-colors duration-200`}>
							<BiX />
						</button>
					</div>

					<p className='px-4 text-neutral-400 font-medium text-sm text-center py-6'>{translations.message}</p>

					<form onSubmit={onSubmit} className='space-y-3 w-auto'>
						<div className='mb-4'>
							<label htmlFor='categories' className='block mb-2 text-sm font-semibold text-neutral-400'>
								Categoría:
							</label>

							<select
								id='categories'
								className='text-slate-500 bg-neutral-50 block w-full p-2 border border-neutral-300 focus:outline-none focus:border-neutral-300 cursor-pointer text-sm'
								value={selectedCategory || ''}
								onChange={handleCategoryChange}>
								<option value='' disabled>
									Selecciona una categoría
								</option>
								{filteredCategories.map(category => (
									<option key={category.id_category} value={category.id_category}>
										{category.name}
									</option>
								))}
							</select>
						</div>

						<div className='mb-4'>
							<label htmlFor='tags' className='block mb-2 text-sm font-semibold text-neutral-400'>
								Etiquetas:
							</label>
							<select
								id='tags'
								className='text-neutral-500 bg-neutral-50 block w-full border border-neutral-300 focus:outline-none focus:border-neutral-300 cursor-pointer text-xs font-medium'
								multiple
								value={selectedTags}
								onChange={handleTagChange}>
								{filteredTags.map(tag => (
									<option
										key={tag.id_tag}
										value={tag.id_tag}
										className='hover:bg-neutral-200 hover:text-neutral-800 p-2 transition-colors duration-100'>
										{tag.name}
									</option>
								))}
							</select>
						</div>

						<div className='grid grid-cols-3 gap-4'>
							{selectedTagsBadgets.map(tag => (
								<div
									onClick={() => handleRemoveBadget(tag.id_tag)}
									key={tag.id_tag}
									className='bg-neutral-100 text-xs text-neutral-500 font-medium border border-neutral-300 px-2 py-1 flex items-center justify-between hover:bg-[#cd664d] cursor-pointer hover:text-neutral-50 transition-colors duration-200'>
									<span className='mr-1'>{tag.name}</span>
									<BiX className='cursor-pointer' />
								</div>
							))}
						</div>

						<div className='flex flex-col gap-2 text-md my-2 text-neutral-500'>
							<button
								type='submit'
								onClick={handleSubmit}
								className={`${colors.bg[1]} ${colors.bg[2]} text-sm text-neutral-50 py-1.5 transition-colors duration-200 focus:outline-none`}>
								<span className='text-sm'>{translations.submit}</span>
							</button>
						</div>
					</form>
				</div>
			</div>
		</>
	)
}

export { ModalSelector }

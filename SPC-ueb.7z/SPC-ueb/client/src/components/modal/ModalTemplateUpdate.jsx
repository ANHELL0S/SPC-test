import React, { useEffect, useState } from 'react'
import { BiListUl, BiX } from 'react-icons/bi'

const ModalSelectorUpdate = ({ initialValues, onSubmit, onClose, translations, colors, associatedTags }) => {
	const [selectedTags, setSelectedTags] = useState([])
	const [filteredTags, setFilteredTags] = useState([])
	const [selectedTagsBadgets, setSelectedTagsBadgets] = useState([])
	const [modalOpen, setModalOpen] = useState(false)
	const [deletedTags, setDeletedTags] = useState([])

	useEffect(() => {
		setModalOpen(true)
	}, [])

	useEffect(() => {
		// Actualizar las etiquetas filtradas cuando cambian las etiquetas asociadas
		setFilteredTags(associatedTags)
	}, [associatedTags])

	const handleTagChange = e => {
		const selectedTagIds = Array.from(e.target.selectedOptions, option => option.value)
		const uniqueSelectedTagIds = Array.from(new Set(selectedTagIds)) // Eliminar duplicados

		// Verificar si el tag ya está seleccionado antes de agregarlo
		const newTags = uniqueSelectedTagIds.filter(tagId => !selectedTags.includes(tagId))

		setSelectedTags(prevTags => [...prevTags, ...newTags]) // Mantener todas las etiquetas seleccionadas

		// Filtrar los nuevos tags seleccionados directamente en initialValues
		const selectedTagsData = initialValues.filter(tag => newTags.includes(tag.id_tag))
		setSelectedTagsBadgets(prevBadgets => [...prevBadgets, ...selectedTagsData])
	}

	const handleRemoveBadget = tagId => {
		setSelectedTags(prevTags => prevTags.filter(id => id !== tagId))
		setSelectedTagsBadgets(prevBadgets => prevBadgets.filter(tag => tag.id_tag !== tagId))

		// Verificar si la etiqueta ya ha sido eliminada antes de agregarla
		if (!deletedTags.includes(tagId)) {
			setDeletedTags(prevDeletedTags => [...prevDeletedTags, tagId]) // Utilizando prevDeletedTags aquí
		}
	}

	const handleSubmit = async e => {
		e.preventDefault()
		const formData = {
			id_tag: selectedTags,
		}
		onSubmit(formData)
	}

	// Obtener los ID de las etiquetas actuales
	const currentTagIds = associatedTags.map(tag => tag.id_tag_fk)

	// Filtrar las etiquetas iniciales basadas en los ID de las etiquetas actuales
	const availableTags = initialValues.filter(tag => !currentTagIds.includes(tag.id_tag))

	return (
		<>
			<div
				className={`fixed inset-0 flex items-center justify-center z-50 bg-neutral-50 transition-opacity ${
					modalOpen ? 'opacity-100' : 'opacity-0'
				}`}>
				<div className={`modal w-auto transition-opacity`}>
					<div
						className={`flex items-center justify-between gap-2 text-md text-neutral-500 font-medium border border-neutral-300 pl-4`}>
						<span className='flex flex-row items-center'>
							<span>{translations.title}</span>
						</span>

						<button
							type='button'
							onClick={onClose}
							className={`flex flex-row items-center py-2 px-4 text-neutral-600 hover:text-neutral-50 bg-neutral-50 ${colors.bg[2]} border-l border-neutral-300 transition-colors duration-200`}>
							<BiX />
						</button>
					</div>

					<p className='px-4 text-neutral-400 font-medium text-sm text-center py-6'>{translations.message}</p>

					<p className='text-left block mb-2 text-sm font-medium text-neutral-400'>Etiquetas actuales:</p>

					<div className='grid grid-cols-3 gap-4'>
						{associatedTags.map(tag => (
							<div
								key={tag.id_tag}
								className='bg-neutral-50 text-neutral-500 text-xs py-1 font-medium border border-neutral-300 px-2 flex items-center'>
								{tag.tag_name}
							</div>
						))}
					</div>

					<form onSubmit={handleSubmit} className='space-y-3 w-auto py-6'>
						<div className='mb-4'>
							<label htmlFor='tags' className='block mb-2 text-sm font-medium text-neutral-400'>
								Seleccionar etiquetas:
							</label>

							<select
								id='tags'
								className='text-neutral-500 bg-neutral-50 block w-full border border-neutral-300 focus:outline-none focus:border-neutral-300 cursor-pointer text-xs font-medium'
								multiple
								value={selectedTags}
								onChange={handleTagChange}>
								{availableTags.length === 0 ? (
									<option disabled>No hay etiquetas disponibles</option>
								) : (
									availableTags.map(tag => (
										<option
											key={tag.id_tag}
											value={tag.id_tag}
											className='hover:bg-neutral-200 hover:text-neutral-800 p-2 transition-colors duration-100'>
											{tag.name}
										</option>
									))
								)}
							</select>
						</div>

						<div className='flex flex-wrap mb-4 gap-2'>
							{selectedTags.map(tagId => {
								const tag = initialValues.find(tag => tag.id_tag === tagId)
								return (
									<div
										key={tag.id_tag}
										onClick={() => handleRemoveBadget(tag.id_tag)}
										className='bg-neutral-100 text-neutral-500 font-medium border border-neutral-300 px-2 py-1 flex items-center hover:bg-[#cd664d] cursor-pointer hover:text-neutral-50 transition-colors duration-200 text-xs'>
										<span className='mr-1'>{tag.name}</span>
										<BiX className='cursor-pointer' />
									</div>
								)
							})}
						</div>

						<div className='flex flex-col gap-2 text-md my-2 text-neutral-500'>
							<button
								type='submit'
								onClick={handleSubmit}
								className={`${colors.bg[1]} ${colors.bg[2]} text-sm text-neutral-50 py-1.5 transition-colors duration-200 focus:outline-none`}>
								<span className='text-sm'>{translations.submit}</span>
							</button>
						</div>
					</form>
				</div>
			</div>
		</>
	)
}

export { ModalSelectorUpdate }

import { Link } from 'react-router-dom'
import { BiRightArrowAlt } from 'react-icons/bi'

const Stadistic = ({ title, link, total, inactiveCount, icon }) => {
	return (
		<div className='flex flex-col bg-white active:border-neutral-300 lg:col-span-3'>
			<div className='flex items-center justify-between gap-2 text-sm bg-white border border-neutral-300 text-neutral-500 pl-4 border-b-transparent rounded-t-lg'>
				<span className='text-xs font-semibold uppercase text-neutral-500'>{title}</span>

				<Link
					to={link}
					className='flex flex-row gap-1 items-center bg-neutral-50 hover:bg-neutral-600 border-l border-neutral-300 hover:text-neutral-50 px-2 py-1 transition-colors duration-200 hover:underline rounded-tr-lg'>
					<BiRightArrowAlt className='text-lg' />
				</Link>
			</div>

			<div className='flex grow items-center justify-between p-4 border border-neutral-300 rounded-b-lg'>
				<div className='flex flex-col'>
					<span className='text-2xl font-semibold text-neutral-500 mb-1'>{total}</span>
					<span className='text-xs font-medium text-[#cd664d]'>{inactiveCount} Inactivos</span>
				</div>

				<div className='flex items-center text-sm font-medium text-neutral-400 p-2'>{icon}</div>
			</div>
		</div>
	)
}

export { Stadistic }

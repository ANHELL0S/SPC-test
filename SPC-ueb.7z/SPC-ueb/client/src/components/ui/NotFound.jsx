import { Link } from 'react-router-dom'

const NotFound = ({ title, description, linkText, linkTo }) => (
	<section className='bg-white'>
		<div className='container min-h-screen px-6 py-12 mx-auto lg:flex lg:items-center lg:gap-12'>
			<div className='wf-ull lg:w-2/3'>
				<p className='text-md font-bold text-sky-400'>Error 404</p>

				<h1 className='mt-3 text-2xl font-semibold text-slate-600 md:text-3xl'>{title}</h1>

				<p className='mt-4 text-slate-500'>{description}</p>

				<div className='flex items-center mt-6 gap-x-3'>
					<Link
						to={linkTo}
						className='w-1/2 px-5 py-2 text-sm tracking-wide text-white transition-colors duration-200 bg-blue-500 rounded-lg shrink-0 sm:w-auto hover:bg-blue-600'>
						{linkText}
					</Link>
				</div>
			</div>
		</div>
	</section>
)

export { NotFound }

import { Route } from 'react-router-dom'
import { ProfilePage } from '../pages/web/ProfilePage'
import { ProtectedRoute } from '../utils/ProtectedRoute'
import { CollectionArticle } from '../pages/web/CollectionArticle'

const ProtectedRoutes = () => (
	<>
		<Route element={<ProtectedRoute />}>
			<Route path='/profile' element={<ProfilePage />} />
			<Route path='/collection-article' element={<CollectionArticle />} />
		</Route>
	</>
)

export { ProtectedRoutes }

import { ProtectedRoute } from '../utils/ProtectedRoute'
import { DashboardPage } from '../pages/admin/DashboardPage'
import { ProfilePage as ProfileAdminPage } from '../pages/admin/ProfilePage'
import { TemplatePage } from '../pages/admin/TemplatePage'

export const AdminRoutes = () => (
	<>
		<ProtectedRoute adminOnly path='/dashboard' element={<DashboardPage />} />
		<ProtectedRoute adminOnly path='/dashboard/perfil/:id' element={<ProfileAdminPage />} />
		<ProtectedRoute adminOnly path='/dashboard/formatos' element={<TemplatePage />} />
	</>
)

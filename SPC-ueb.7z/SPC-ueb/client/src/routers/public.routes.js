import { Route } from 'react-router-dom'
import { LandingPage } from '../pages/web/LandingPage'
import { LoginPage } from '../pages/auth/LoginPage'
import { RegisterPage } from '../pages/auth/RegisterPage'
import { HomePage } from '../pages/web/HomePage'
import { ArticlePage } from '../pages/web/ArticlePage'

const PublicRoutes = () => (
	<>
		<Route path='/' element={<LandingPage />} />
		<Route path='/login' element={<LoginPage />} />
		<Route path='/register' element={<RegisterPage />} />
		<Route path='/artículos' element={<HomePage />} />
		<Route path='/article/:id_article' element={<ArticlePage />} />
	</>
)

export default PublicRoutes

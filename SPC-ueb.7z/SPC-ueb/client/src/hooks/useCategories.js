import { useEffect, useState } from 'react'
import { fetch, count } from '../services/api/categories.api'

const useCategoriesData = () => {
	const [categories, setCategories] = useState([])

	useEffect(() => {
		const fetchCategoriesData = async () => {
			try {
				const categoryData = await fetch()
				setCategories(categoryData)
			} catch (error) {
				console.error(error)
			}
		}

		fetchCategoriesData()
	}, [])

	return categories
}

const useCategoryCount = () => {
	const [categoryCount, setCategoryCount] = useState(0)

	useEffect(() => {
		const fetchCategoryCount = async () => {
			try {
				const countData = await count()
				setCategoryCount(countData)
			} catch (error) {
				console.error(error)
			}
		}

		fetchCategoryCount()
	}, [])

	return categoryCount
}

export { useCategoriesData, useCategoryCount }

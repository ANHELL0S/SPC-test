import { toast } from 'sonner'
import { useEffect, useState } from 'react'
import { fetch, getCount } from '../services/api/users.api'

const useUsers = id_user => {
	const [users, setUsers] = useState([])
	const [loading, setLoading] = useState(true)
	const [userCount, setUserCount] = useState(0)

	useEffect(() => {
		const fetchUsers = async () => {
			try {
				const usersData = await fetch()
				setUsers(usersData)
			} catch (error) {
				toast.error(`Error fetching users: ${error.message}`)
			} finally {
				setLoading(false)
			}
		}

		const fetchUserCount = async () => {
			try {
				const countData = await getCount()
				setUserCount(countData)
			} catch (error) {
				toast.error(`Error fetching user count: ${error.message}`)
			}
		}

		fetchUsers()
		fetchUserCount()
	}, [id_user])

	return {
		users,
		loading,
		userCount,
	}
}

export { useUsers }

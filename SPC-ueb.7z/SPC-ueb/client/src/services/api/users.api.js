import { usersInstance } from './config/axios'

const getCount = async () => {
	try {
		const response = await usersInstance.get('/getCount')
		return response.data
	} catch (error) {
		throw new Error(`Error fetching users: ${error.response.data.message}`)
	}
}

const getById = async id => {
	try {
		const response = await usersInstance.get(`/${id}`)
		return response.data
	} catch (error) {
		throw new Error(`Error fetching user: ${error.response.data.message}`)
	}
}

const fetch = async () => {
	try {
		const response = await usersInstance.get('/')
		return response.data
	} catch (error) {
		throw new Error(`Error fetching users: ${error.response.data.message}`)
	}
}

const create = async data => {
	try {
		const response = await usersInstance.post('/create', data)
		return response.data
	} catch (error) {
		throw new Error(`${error.response.data.message}`)
	}
}

const update = async (id, data) => {
	try {
		const response = await usersInstance.put(`/update/${id}`, data)
		return response.data
	} catch (error) {
		throw new Error(`${error.response.data.message}`)
	}
}

const updateUsername = async (id, data) => {
	try {
		const response = await usersInstance.put(`/updateUsername/${id}`, data)
		return response.data
	} catch (error) {
		throw new Error(`${error.response.data.message}`)
	}
}

const updateEmail = async (id, data) => {
	try {
		const response = await usersInstance.put(`/updateEmail/${id}`, data)
		return response.data
	} catch (error) {
		throw new Error(`${error.response.data.message}`)
	}
}

const updatePassword = async (id, data) => {
	try {
		const response = await usersInstance.put(`/updatePassword/${id}`, data)
		return response.data
	} catch (error) {
		throw new Error(`${error.response.data.message}`)
	}
}

const remove = async id => {
	try {
		const response = await usersInstance.delete(`/remove/${id}`)
		return response.data
	} catch (error) {
		throw new Error(`${error.response.data.message}`)
	}
}

const reactive = async id => {
	try {
		const response = await usersInstance.put(`/reactive/${id}`)
		return response.data
	} catch (error) {
		throw new Error(`${error.response.data.message}`)
	}
}

export { getCount, getById, fetch, create, update, updateUsername, updateEmail, updatePassword, remove, reactive }

import { movementsInstance } from './config/axios'

export const fetch = async () => {
	try {
		const response = await movementsInstance.get('/')
		return response.data
	} catch (error) {
		throw new Error(`Error fetching movements: ${error.message}`)
	}
}

import { Toaster, toast } from 'sonner'
import { Link } from 'react-router-dom'
import AuthContext from '../../context/AuthContext'
import { Spinner } from '../../components/ui/spinner'
import { useTransition, animated } from 'react-spring'
import { useState, useEffect, useContext } from 'react'
import { formatDate } from '../../utils/dataFormater.utils'
import { getByIdUser, update } from '../../services/api/article.api'
import { ButtonLoadingSpinner } from '../../components/ui/ButtomSpinner'
import {
	BiArrowFromLeft,
	BiArrowFromRight,
	BiArrowToLeft,
	BiCalendarAlt,
	BiCheckCircle,
	BiDetail,
	BiEditAlt,
	BiGroup,
	BiLeftArrow,
	BiLink,
	BiListOl,
	BiRightArrow,
	BiX,
} from 'react-icons/bi'
import { BarLeft } from '../../components/BarLeft'
import { BarRight } from '../../components/BarRight'
import { BottomBar } from '../../components/BarDown'

const MyArticlePage = () => {
	const { user } = useContext(AuthContext)
	const id = user.id_user
	const [loading, setLoading] = useState(false)
	const [rendering, setRendering] = useState(false)
	const [articles, setArticles] = useState([])
	const [selectedArticle, setSelectedArticle] = useState(null)
	const [isModalOpen, setIsModalOpen] = useState(false)
	const [isReviewsModalOpen, setIsReviewsModalOpen] = useState(false)
	const [showDetailsModal, setShowDetailsModal] = useState(false)
	const [selectedReviews, setSelectedReviews] = useState([])
	const [formData, setFormData] = useState({
		title: '',
		author: '',
		link: '',
		category_name: '',
		manager_name: '',
		summary: '',
		parameters: [],
		tags: [],
	})

	useEffect(() => {
		const fetchArticles = async () => {
			setRendering(true)
			try {
				const fetchedArticles = await getByIdUser(id)
				setArticles(fetchedArticles)

				// Si hay un artículo seleccionado, actualiza los campos de title y summary
				if (selectedArticle) {
					const selected = fetchedArticles.find(article => article.id_article === selectedArticle.id_article)
					if (selected) {
						setFormData(prevFormData => ({
							...prevFormData,
						}))
					}
				}
			} catch (error) {
				toast.error(`${error.message}`)
			} finally {
				setRendering(false)
			}
		}

		fetchArticles()
	}, [id, selectedArticle])

	const handleEditClick = article => {
		setSelectedArticle(article)
		setFormData({
			title: article.title,
			author: article.author,
			link: article.link,
			category_name: article.category_name,
			manager_name: article.manager_name,
			summary: article.summary,
			parameters: article.parameters,
			tags: article.tags,
		})
		setIsModalOpen(true)
	}

	const handleInputChange = e => {
		const { name, value } = e.target
		setFormData({
			...formData,
			[name]: value,
		})
	}

	const handleParameterChange = (index, e) => {
		const { name, value } = e.target
		const newParameters = [...formData.parameters]
		newParameters[index][name] = value
		setFormData({
			...formData,
			parameters: newParameters,
		})
	}

	const handleTagChange = (index, e) => {
		const { name, value } = e.target
		const newTags = [...formData.tags]
		newTags[index][name] = value
		setFormData({
			...formData,
			tags: newTags,
		})
	}

	const handleSaveChanges = async () => {
		try {
			setLoading(true)
			const updatedFormData = { ...formData }

			updatedFormData.parameters = updatedFormData.parameters.map(parameter => ({
				id_relation_parameter_article: parameter.id_relation_parameter_article,
				description_parameter: parameter.description_parameter,
			}))

			updatedFormData.tags = updatedFormData.tags.map(tag => ({
				id_relation_tag_article: tag.id_relation_tag_article,
				description_tag: tag.description_tag,
			}))

			// Llamar a la función de actualización en el backend con los datos actualizados
			const response = await update(selectedArticle.id_article, updatedFormData)

			// Actualizar el estado de los artículos con los datos actualizados
			setArticles(prevArticles =>
				prevArticles.map(article =>
					article.id_article === selectedArticle.id_article ? { ...article, ...updatedFormData } : article
				)
			)

			toast.success(`${response.message}`)
		} catch (error) {
			toast.error(`${error.message}`)
		} finally {
			setLoading(false)
			setIsModalOpen(false)
			setSelectedArticle(null)
		}
	}

	const handleReviewsClick = reviews => {
		setSelectedReviews(reviews)
		setIsReviewsModalOpen(true)
	}

	const handleDetailsClick = article => {
		setSelectedArticle(article)
		setShowDetailsModal(true)
	}

	const transitions = useTransition(isModalOpen, {
		from: { opacity: 0 },
		enter: { opacity: 1 },
		leave: { opacity: 0 },
		config: { tension: 150, friction: 15 },
	})

	const reviewsTransitions = useTransition(isReviewsModalOpen, {
		from: { opacity: 0 },
		enter: { opacity: 1 },
		leave: { opacity: 0 },
		config: { tension: 150, friction: 15 },
	})

	return (
		<>
			<BarLeft />
			<BarRight />
			<BottomBar />

			{rendering ? (
				<Spinner />
			) : (
				<main className='px-4 pb-12'>
					<div className='bg-white w-full flex justify-between items-center max-w-5xl mx-auto mt-4'>
						<div className='flex flex-col'>
							<div className='flex gap-x-6 flex-row'>
								<h2 className='text-lg font-semibold text-slate-700'>Mis artículos ({articles.length})</h2>
							</div>
						</div>
					</div>

					<div className='max-w-5xl mx-auto bg-white text-slate-600 w-full border-t my-4'>
						<div className='flex flex-col'>
							<div className='max-w-5xl mx-auto bg-white text-slate-600 w-full'>
								{articles.map(article => (
									<div key={article.id_article} className='border-b py-4 px-4 my-6 rounded-lg border border-slate-300'>
										<div className='flex items-center justify-between'>
											<div className='flex items-center text-xs gap-1 pb-2 text-slate-500'>
												<BiCalendarAlt />
												<span>{formatDate(article.createdAt)}</span>
											</div>

											<div className='text-xs text-slate-600 flex gap-2'>
												<button
													className='p-2 rounded-full hover:bg-slate-100 hover:text-slate-800 cursor-pointer transition-colors duration-150'
													onClick={() => handleEditClick(article)}>
													<BiEditAlt />
												</button>

												<button
													className='p-2 rounded-full hover:bg-slate-100 hover:text-slate-800 cursor-pointer transition-colors duration-150'
													onClick={() => handleReviewsClick(article.reviews)}>
													<BiListOl />
												</button>
											</div>
										</div>

										<div>
											<Link
												to={`/article/${article.id_article}`}
												className='sm:text-lg text-sm font-bold hover:underline'>
												{article.title}
											</Link>
										</div>

										<div className='text-sm font-medium text-slate-400 flex items-center gap-1'>
											<BiGroup />
											<h1>{article.author}</h1>
										</div>

										<div className='text-slate-500 flex flex-col text-xs sm:text-sm pt-2 gap-y-1 font-medium'>
											<div className='flex items-center gap-1'>
												<BiCheckCircle className={article.status === 'aprobado' ? 'text-green-500' : ''} />
												<span className={article.status === 'aprobado' ? 'text-green-500' : ''}>{article.status}</span>
											</div>
										</div>

										<div className='text-slate-500 flex flex-row items-center gap-1 sm:text-sm text-xs pt-2 gap-y-1 font-medium'>
											<BiLink />
											<a href={article.link} className='hover:underline text-sky-600 hover:text-sky-800'>
												{article.link}
											</a>
										</div>

										<div className='flex flex-col gap-y-2 text-sm my-4 text-slate-500'>
											<p className='font-normal'>
												{article.summary.length > 250 ? `${article.summary.slice(0, 250)}...` : article.summary}
											</p>
										</div>

										<hr className='border-1 border-slate-300 mt-4' />

										<div
											onClick={() => handleDetailsClick(article)}
											className='flex flex-row items-center gap-1 text-xs mt-4 font-medium text-slate-500 hover:underline cursor-pointer hover:text-slate-600'>
											<span>Ver más detalles</span>
											<BiRightArrow />
										</div>
									</div>
								))}
							</div>
						</div>
					</div>

					{showDetailsModal && (
						<div className='fixed z-50 inset-0 bg-neutral-50 py-4'>
							<div className='fixed z-50 inset-0 bg-neutral-50 py-4 overflow-y-scroll'>
								<div className='flex items-end justify-center px-4 text-center sm:block sm:p-0'>
									<div className='sm:inline-block align-bottom bg-white text-left transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full border border-slate-300 rounded-lg text-slate-600'>
										<div className='flex justify-between items-center px-4 pt-4'>
											<div className='border rounded-lg p-2'>
												<BiDetail />
											</div>

											<div
												onClick={() => setShowDetailsModal(false)}
												className='hover:bg-slate-100 hover:text-slate-800 text-slate-500 p-2 text-xl rounded-full cursor-pointer transition-colors duration-150'>
												<BiX />
											</div>
										</div>

										<div className='px-4 pt-4 text-slate-600 text-md font-semibold flex flex-col gap-y-1'>
											<span>Detalles del artículo</span>
										</div>

										<div className='flex flex-col gap-y-2 text-xs text-slate-600 px-4 py-4'>
											{selectedArticle.parameters.length === 0 && selectedArticle.tags.length === 0 && (
												<span className='font-medium text-slate-700'>No hay detalles para este artículo.</span>
											)}

											{selectedArticle.parameters.map(parameter => (
												<>
													<div className='flex flex-row gap-2'>
														<span className='font-medium text-slate-700'>{parameter.name_parameter}: </span>
														<span key={parameter.id_relation_parameter_article}>{parameter.description_parameter}</span>
													</div>
												</>
											))}

											{selectedArticle.tags.map(tag => (
												<>
													<div className='flex flex-row gap-2'>
														<span className='font-medium text-slate-700'>{tag.name_tag}: </span>
														<span key={tag.id_relation_tag_article}>{tag.description_tag}</span>
													</div>
												</>
											))}
										</div>
									</div>
								</div>
							</div>
						</div>
					)}

					{transitions(
						(style, item) =>
							item && (
								<animated.div style={style} className='fixed z-50 inset-0 bg-neutral-50 py-4'>
									{isModalOpen && (
										<div className='fixed z-50 inset-0 bg-neutral-50 py-4 overflow-y-scroll'>
											<div className='flex items-end justify-center px-4 text-center sm:block sm:p-0'>
												<div className='sm:inline-block align-bottom bg-white text-left transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full border border-slate-300 rounded-lg text-slate-600'>
													<div className='flex justify-between items-center px-4 pt-4'>
														<div className='border rounded-lg p-2'>
															<BiEditAlt />
														</div>

														<div
															onClick={() => setIsModalOpen(false)}
															className='hover:bg-slate-100 hover:text-slate-800 text-slate-500 p-2 text-xl rounded-full cursor-pointer transition-colors duration-150'>
															<BiX />
														</div>
													</div>

													<div className='px-4 py-4 text-slate-600 text-md font-semibold flex flex-col gap-y-1'>
														<span>Editar artículo</span>
														<span className='text-slate-500 font-normal text-xs'>
															Por favor, asegúrate de ingresar la información correctamente en el formulario.
														</span>
													</div>

													<div className='flex flex-col gap-y-2 text-xs text-slate-600 px-4'>
														<div className='grid grid-cols-1 gap-x-4 gap-y-3 pt-2'>
															<div className='flex flex-col gap-y-2'>
																<label className='text-slate-600'>Título</label>
																<input
																	type='text'
																	name='title'
																	value={formData.title}
																	onChange={handleInputChange}
																	className='border rounded-lg p-2 text-slate-500'
																	placeholder='Descripción de la etiqueta'
																/>
															</div>
														</div>

														<div className='grid grid-cols-1 gap-x-4 gap-y-3 pt-2'>
															<div className='flex flex-col gap-y-2'>
																<label className='text-slate-600'>Autor</label>
																<input
																	type='text'
																	name='author'
																	value={formData.author}
																	onChange={handleInputChange}
																	className='border rounded-lg p-2 text-slate-500'
																	placeholder='Descripción de la etiqueta'
																/>
															</div>
														</div>

														<div className='grid grid-cols-1 gap-x-4 gap-y-3 pt-2'>
															<div className='flex flex-col gap-y-2'>
																<label className='text-slate-600'>Link</label>
																<input
																	type='text'
																	name='link'
																	value={formData.link}
																	onChange={handleInputChange}
																	className='border rounded-lg p-2 text-slate-500'
																	placeholder='Descripción de la etiqueta'
																/>
															</div>
														</div>

														<div className='grid grid-cols-1 gap-x-4 gap-y-3 pt-2'>
															<div className='flex flex-col gap-y-2'>
																<label className='text-slate-600'>Resumen</label>
																<textarea
																	name='summary'
																	value={formData.summary}
																	onChange={handleInputChange}
																	className='border rounded-lg p-2 text-slate-500'
																	placeholder='Descripción de la etiqueta'
																/>
															</div>
														</div>

														<div className='text-slate-600'>
															{formData.parameters.map((parameter, index) => (
																<div
																	key={parameter.id_relation_parameter_article}
																	className='flex flex-col gap-y-2 py-2'>
																	<label className='text-slate-600'>{parameter.name_parameter}:</label>
																	<input
																		type='text'
																		name='description_parameter'
																		value={parameter.description_parameter}
																		onChange={e => handleParameterChange(index, e)}
																		className='border rounded-lg p-2 text-slate-500'
																		placeholder='Descripción del parámetro'
																	/>
																</div>
															))}
														</div>

														<div className='text-slate-600'>
															{formData.tags.map((tag, index) => (
																<div key={tag.id_relation_tag_article} className='flex flex-col gap-y-2 py-2'>
																	<label className='text-slate-600'>{tag.name_tag}:</label>
																	<input
																		type='text'
																		name='description_tag'
																		value={tag.description_tag}
																		onChange={e => handleTagChange(index, e)}
																		className='border rounded-lg p-2 text-slate-500'
																		placeholder='Descripción de la etiqueta'
																	/>
																</div>
															))}
														</div>

														<div className='flex justify-between py-4 font-semibold gap-4 flex-col sm:flex-row'>
															<button
																onClick={() => setIsModalOpen(false)}
																className='flex-1 px-4 py-3 border border-slate-300 text-slate-600 rounded-lg hover:bg-slate-100 transition-colors duration-150'>
																Cancelar
															</button>

															<button
																onClick={handleSaveChanges}
																className={`flex-1 px-4 py-3 bg-sky-700 text-white rounded-lg hover:bg-sky-800 transition-colors duration-150 disabled:opacity-50' inline-flex h-10 items-center justify-center hover:text-white hover:ring hover:ring-white disabled:pointer-events-none ${
																	loading ? 'cursor-not-allowed' : ''
																}`}>
																{loading ? (
																	<ButtonLoadingSpinner loadingText='Guardando cambios...' />
																) : (
																	'Guardar cambios'
																)}
															</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									)}
								</animated.div>
							)
					)}

					{reviewsTransitions(
						(style, item) =>
							item && (
								<animated.div style={style} className='fixed z-50 inset-0 bg-neutral-50 py-4'>
									{isReviewsModalOpen && (
										<div className='fixed z-50 inset-0 bg-neutral-50 py-4 overflow-y-scroll'>
											<div className='flex items-end justify-center px-4 text-center sm:block sm:p-0'>
												<div className='sm:inline-block align-bottom bg-white text-left transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full border border-slate-300 rounded-lg text-slate-600'>
													<div className='flex justify-between items-center px-4 pt-4'>
														<div className='border rounded-lg p-2'>
															<BiListOl />
														</div>
														<div
															onClick={() => setIsReviewsModalOpen(false)}
															className='hover:bg-slate-100 hover:text-slate-800 text-slate-500 p-2 text-xl rounded-full cursor-pointer transition-colors duration-150'>
															<BiX />
														</div>
													</div>
													<div className='px-4 py-4 text-slate-600 text-md font-semibold flex flex-col gap-y-1'>
														<span>Revisiones del artículo</span>

														<span className='text-slate-500 font-normal text-xs'>
															Por favor, asegúrate de completar todas las revisiones correctamente para que tu artículo
															sea aprobado.
														</span>
													</div>

													<div className='flex flex-col text-xs text-slate-600 px-4 pb-4'>
														{selectedReviews.length > 0 ? (
															selectedReviews.map(review => (
																<div key={review.id_review} className='border-b order-1 py-2 space-y-1'>
																	<div className='flex flex-row items-center gap-1 text-slate-400'>
																		<BiCalendarAlt />
																		<span>{formatDate(review.createdAt)}</span>
																	</div>

																	<div className='flex flex-row items-center gap-2 justify-between text-slate-500'>
																		<div className='text-sm'>{review.task}</div>
																		<div
																			className={`flex items-center gap-1 font-medium px-2 py-0.5 rounded-full ${
																				review.status === 'pendiente' ? 'bg-orange-100' : 'bg-green-100'
																			}`}>
																			<BiCheckCircle
																				className={review.status === 'pendiente' ? 'text-orange-500' : 'text-green-600'}
																			/>
																			<span
																				className={`uppercase ${
																					review.status === 'pendiente' ? 'text-orange-500' : 'text-green-500'
																				}`}>
																				{review.status}
																			</span>
																		</div>
																	</div>
																</div>
															))
														) : (
															<div className='text-slate-400 flex flex-col text-sm py-6 font-medium'>
																<span>No hay reseñas disponibles.</span>
															</div>
														)}
													</div>
												</div>
											</div>
										</div>
									)}
								</animated.div>
							)
					)}
				</main>
			)}

			<Toaster richColors expand={true} />
		</>
	)
}

export { MyArticlePage }

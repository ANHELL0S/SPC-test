import { Toaster, toast } from 'sonner'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { create } from '../../services/api/article.api'
import { fetch as fetchTemplate } from '../../services/api/template.api'
import { ButtonLoadingSpinner } from '../../components/ui/ButtomSpinner'
import { BarLeft } from '../../components/BarLeft'
import { BarRight } from '../../components/BarRight'
import { BottomBar } from '../../components/BarDown'

const CreateArticlePage = () => {
	const [categories, setCategories] = useState([])
	const [loading, setLoading] = useState(false)
	const [selectedCategory, setSelectedCategory] = useState('')
	const [selectedTags, setSelectedTags] = useState([])
	const [selectedParameter, setSelectedParameter] = useState([])
	const [descriptions, setDescriptions] = useState({})
	const [descriptionsParameter, setDescriptionsParameter] = useState({})
	const [title, setTitle] = useState('')
	const [author, setAuthor] = useState('')
	const [summary, setSummary] = useState('')
	const [link, setLink] = useState('')
	const navigate = useNavigate()

	useEffect(() => {
		fetchData()
	}, [])

	const fetchData = async () => {
		try {
			const data = await fetchTemplate()
			setCategories(data)
		} catch (error) {
			console.error('Error fetching templates:', error)
		}
	}

	const handleSubmit = async () => {
		try {
			const categoryId = categories.find(category => category.category_name === selectedCategory)?.id_category_fk
			const selectedCategoryData = categories.find(category => category.category_name === selectedCategory)
			const idTemplate = selectedCategoryData ? selectedCategoryData.id_template : null
			const tagIds = selectedTags.map(tag => tag.id_tag_fk)
			const parameterIds = selectedParameter.map(parameter => parameter.id_parameter)

			const articleData = {
				id_template: idTemplate,
				id_category_fk: categoryId,
				title: title,
				author: author,
				summary: summary,
				link: link,
				id_parameter_fk: parameterIds,
				id_tag_fk: tagIds,
				descriptions: descriptions,
				descriptions_parameter: descriptionsParameter,
			}

			const response = await create(articleData)
			setLoading(true)
			toast.success(`${response.message}`)
			navigate('/artículos')
		} catch (error) {
			setLoading(false)
			toast.error(`${error.message}`)
		}
	}

	const handleCategorySelect = category_name => {
		setSelectedCategory(category_name)
		const selectedCategoryData = categories.find(category => category.category_name === category_name)
		if (selectedCategoryData) {
			setSelectedTags(selectedCategoryData.tags)
			setSelectedParameter(selectedCategoryData.parameter)
		} else {
			setSelectedTags([])
		}
	}

	const handleDescriptionChange = (tagId, description) => {
		setDescriptions(prevState => ({
			...prevState,
			[tagId]: description,
		}))
	}

	const handleDescriptionParameterChange = (tagParameter, description) => {
		setDescriptionsParameter(prevState => ({
			...prevState,
			[tagParameter]: description,
		}))
	}

	return (
		<>
			<BarLeft />

			<BarRight />

			<BottomBar />

			<main className='px-4 max-w-5xl mx-auto text-start justify-start my-2 text-slate-700 text-sm pb-12'>
				<div className='py-4 text-slate-600 text-lg font-semibold flex flex-col gap-y-1'>
					<span>Subir artículo</span>
					<span className='text-slate-500 font-normal text-xs'>
						Por favor, selecciona la categoria a la que se ajusta tu artículo.
					</span>
				</div>

				<div className='flex flex-col gap-y-2 text-xs text-slate-600'>
					<label htmlFor='categorySelect' className='block font-medium'>
						Selecciona la categoría:
					</label>

					<select
						id='categorySelect'
						className='block w-full px-4 py-2 mt-1 border bg-white rounded-lg focus:outline-none focus:border-blue-400'
						onChange={e => handleCategorySelect(e.target.value)}
						value={selectedCategory}>
						<option value='' disabled>
							Selecciona una categoría
						</option>
						{categories.map((category, index) => (
							<option key={index} value={category.category_name}>
								{category.category_name}
							</option>
						))}
					</select>
				</div>

				{selectedCategory && (
					<div className='flex flex-col gap-y-2 text-xs text-slate-600 px-4 pt-6 border rounded-lg my-6'>
						<div className='text-slate-600 text-md font-semibold flex flex-col gap-y-1 pb-4'>
							<h2>Formulario del artículo</h2>
							<span className='text-slate-500 font-normal text-xs'>
								Por favor, asegúrate de ingresar la información correctamente para la creación del nuevo artículo, al
								subir un artículo primero deberá pasar por la etapa de aprobación.
							</span>
						</div>

						<div className='grid grid-cols-1 gap-x-4 gap-y-3'>
							<div className='flex flex-col gap-y-2'>
								<label className='text-slate-600'>
									Título <span className='text-red-500'>*</span>
								</label>
								<input
									type='text'
									value={title}
									onChange={e => setTitle(e.target.value)}
									className='border rounded-lg p-2 text-slate-500'
									placeholder='Título del artículo'
								/>
							</div>
						</div>

						<div className='grid grid-cols-1 gap-x-4 gap-y-3'>
							<div className='flex flex-col gap-y-2'>
								<label className='text-slate-600'>
									Autor <span className='text-red-500'>*</span>
								</label>
								<input
									type='text'
									value={author}
									onChange={e => setAuthor(e.target.value)}
									className='border rounded-lg p-2 text-slate-500'
									placeholder='Título del artículo'
								/>
							</div>
						</div>

						<div className='grid grid-cols-1 gap-x-4 gap-y-3 pt-2'>
							<div className='flex flex-col gap-y-2'>
								<label className='text-slate-600'>
									Resumen <span className='text-red-500'>*</span>
								</label>
								<textarea
									value={summary}
									onChange={e => setSummary(e.target.value)}
									className='border rounded-lg p-2 text-slate-500'
									placeholder='Resumen del artículo'
								/>
							</div>
						</div>

						<div className='grid grid-cols-1 gap-x-4 gap-y-3 pt-2'>
							<div className='flex flex-col gap-y-2'>
								<label className='text-slate-600'>
									Link <span className='text-red-500'>*</span>
								</label>
								<input
									type='text'
									value={link}
									onChange={e => setLink(e.target.value)}
									className='border rounded-lg p-2 text-slate-500'
									placeholder='Link del artículo'
								/>
							</div>
						</div>

						<div className='text-slate-600'>
							<div className='grid grid-cols-1 gap-y-4 pt-2 md:grid-cols-2 md:gap-x-4 md:gap-y-2'>
								{selectedParameter.map((parameter, index) => (
									<div key={index} className='flex flex-col gap-y-2'>
										<label htmlFor={`parameter_${index}`} className='text-slate-600'>
											{parameter.name_parameter} <span className='text-red-500'>*</span>
										</label>
										<input
											type='text'
											id={`parameter_${index}`}
											name={`parameter_${index}`}
											value={parameter.description_parameter}
											onChange={e => handleDescriptionParameterChange(parameter.id_parameter, e.target.value)}
											className='border rounded-lg p-2 text-slate-500'
											placeholder={`${parameter.name_parameter} del artículo`}
										/>
									</div>
								))}
							</div>
						</div>

						{selectedTags.length > 0 && (
							<div className='text-slate-600'>
								<div className='grid grid-cols-1 gap-y-4 pt-2 md:grid-cols-2 md:gap-x-4 md:gap-y-2'>
									{selectedTags.map((tag, index) => (
										<div key={index} className='flex flex-col gap-y-2'>
											<label htmlFor={`tag_${index}`} className='text-slate-600'>
												{tag.tag_name} <span className='text-red-500'>*</span>
											</label>
											<input
												type='text'
												id={`tag_${index}`}
												name={`tag_${index}`}
												onChange={e => handleDescriptionChange(tag.id_tag_fk, e.target.value)}
												className='border rounded-lg p-2 text-slate-500'
												placeholder={`${tag.tag_name} del artículo`}
											/>
										</div>
									))}
								</div>
							</div>
						)}

						<div className='flex justify-between py-4 font-semibold gap-4'>
							<button
								onClick={handleSubmit}
								className={`flex-1 px-4 bg-sky-700 text-white rounded-lg hover:bg-sky-800 transition-colors duration-150 disabled:opacity-50 inline-flex h-10 items-center justify-center hover:text-white hover:ring hover:ring-white disabled:pointer-events-none ${
									loading ? 'cursor-not-allowed' : ''
								}`}>
								{loading ? <ButtonLoadingSpinner loadingText='Subiendo artículo...' /> : 'Subir artículo'}
							</button>
						</div>
					</div>
				)}
			</main>

			<Toaster richColors expand={true} />
		</>
	)
}

export { CreateArticlePage }

import { Toaster, toast } from 'sonner'
import { useEffect, useState } from 'react'
import Navbar from '../../components/Navbar'
import { fetch } from '../../services/api/categories.api'
import { formatDate } from '../../utils/dataFormater.utils'
import CustomDataTable from '../../components/table/TableGeneric'
import { BiSolidEditAlt, BiRevision, BiTrashAlt, BiDotsVertical } from 'react-icons/bi'
import { ModalCreate, ModalUpdate, ModalRemove, ModalReactive } from '../../components/form/FormsCategory'

const CategoryPage = () => {
	const [loading, setLoading] = useState(true)
	const [menuOpen, setMenuOpen] = useState({})
	const [selected, setSelected] = useState(null)
	const [toDelete, setToDelete] = useState(null)
	const [categories, setCategories] = useState([])
	const [showUpdateModal, setShowUpdateModal] = useState(false)
	const [showCreateModal, setShowCreateModal] = useState(false)
	const [showDeleteModal, setShowDeleteModal] = useState(false)
	const [showReactiveModal, setShowReactiveModal] = useState(false)

	const toggleMenu = Id => {
		setMenuOpen(prevState => {
			const updatedState = Object.fromEntries(
				Object.entries(prevState).map(([id, isOpen]) => [id, id === Id ? !isOpen : false])
			)
			return {
				...updatedState,
				[Id]: !prevState[Id],
			}
		})
	}

	const handleCloseMenu = () => {
		setMenuOpen({})
	}

	useEffect(() => {
		fetchData()
	}, [])

	const fetchData = async () => {
		try {
			const data = await fetch()
			setCategories(data)
			setLoading(false)
		} catch (error) {
			setLoading(true)
			toast.error('Error al cargar categorias.')
		}
	}

	const handleAdd = () => {
		setShowCreateModal(true)
	}

	const toggleCreateModal = () => {
		setShowCreateModal(!showCreateModal)
	}

	const handleCreateCallback = async () => {
		try {
			await fetchData()
		} catch (error) {
			toast.error('Error al cargar categorias.')
		}
	}

	const handleUpdate = category => {
		setSelected(category)
		setShowUpdateModal(true)
	}

	const toggleUpdateModal = () => {
		setShowUpdateModal(!showUpdateModal)
	}

	const handleUpdateCallback = async () => {
		try {
			await fetchData()
		} catch (error) {
			toast.error('Error al cargar categorias.')
		}
	}

	const handleDelete = category => {
		setToDelete(category)
		setShowDeleteModal(true)
	}

	const toggleDeleteModal = () => {
		setShowDeleteModal(!showDeleteModal)
	}

	const handleDeleteCallback = async () => {
		try {
			await fetchData()
		} catch (error) {
			toast.error('Error al cargar categorias.')
		}
	}

	const handleReactive = category => {
		setSelected(category)
		setShowReactiveModal(true)
	}

	const toggleReactiveModal = () => {
		setShowReactiveModal(!showReactiveModal)
	}

	const handleReactiveCallback = async () => {
		try {
			await fetchData()
		} catch (error) {
			toast.error('Error al cargar categorias.')
		}
	}

	const columns = [
		{
			name: 'Nombre',
			selector: row => row.name,
			sortable: true,
			reorder: true,
			wrap: true,
			maxWidth: '200px',
			format: row => (row.name.length > 60 ? `${row.name.slice(0, 60)}...` : row.name),
		},
		{
			name: 'Descripcion',
			selector: row => row.description,
			sortable: true,
			reorder: true,
			wrap: true,
			maxWidth: '800px',
			format: row => (row.description.length > 60 ? `${row.description.slice(0, 60)}...` : row.description),
		},
		{
			name: 'Estado',
			selector: row => (row.active ? 'Activo' : 'Inactivo'),
			sortable: true,
			reorder: true,
			maxWidth: '0',
			cell: row => (
				<span className={row.active ? 'text-[#009b5d] font-medium' : 'text-[#cd664d] font-medium'}>
					{row.active ? 'Activo' : 'Inactivo'}
				</span>
			),
		},
		{
			name: 'Creado',
			selector: row => row.createdAt,
			sortable: true,
			reorder: true,
			cell: row => <span className='text-xs'>{row.createdAt}</span>,
		},
		{
			name: 'Actualizado',
			selector: row => row.updatedAt,
			sortable: true,
			reorder: true,
			cell: row => <span className='text-xs'>{row.updatedAt}</span>,
		},
		{
			maxWidth: '0',
			cell: category => (
				<div className='flex gap-2 pl-8'>
					{category.active ? (
						<>
							<div
								onClick={() => toggleMenu(category.id)}
								className='hover:bg-neutral-600 bg-neutral-100 hover:text-neutral-50 p-1.5 rounded-lg transition-colors duration-150'>
								<BiDotsVertical />
							</div>

							{menuOpen[category.id] && (
								<div className='flex flex-col absolute right-16 z-50'>
									<ul className='flex flex-row z-50 border bg-neutral-50 border-neutral-300 rounded-lg text-neutral-500'>
										<li
											onClick={() => {
												handleUpdate(category)
												handleCloseMenu()
											}}
											className='py-1 px-1.5 hover:bg-neutral-600 hover:text-neutral-50 rounded-l-lg transition-colors duration-150'>
											<span className='flex items-center'>
												<BiSolidEditAlt className='text-base' />
											</span>
										</li>

										<li
											onClick={() => {
												handleDelete(category)
												handleCloseMenu()
											}}
											className='py-1 px-1.5 border-l border-neutral-300 hover:bg-[#cd664d] hover:text-neutral-50 rounded-r-lg transition-colors duration-150'>
											<span className='flex items-center'>
												<BiTrashAlt className='text-base' />
											</span>
										</li>
									</ul>
								</div>
							)}
						</>
					) : (
						<button
							onClick={() => handleReactive(category)}
							className='hover:bg-neutral-600 bg-green-100 hover:text-neutral-50 p-1.5 rounded-lg transition-colors duration-150'>
							<BiRevision />
						</button>
					)}
				</div>
			),
		},
	]

	const data = categories.map(category => ({
		id: category.id_category,
		name: category.name,
		description: category.description,
		active: category.active,
		createdAt: formatDate(category.createdAt),
		updatedAt: formatDate(category.updatedAt),
	}))

	return (
		<>
			<Navbar />

			<div className='h-screen lg:end-0 lg:start-0 lg:top-0 lg:h-20'>
				<main className='container mx-auto px-4 lg:px-8 xl:max-w-7xl'>
					<div className='lg:py-16 sm:py-0'>
						<div className='flex items-center justify-center py-1 mt-4 text-md gap-2 font-semibold bg-neutral-50 border border-b-transparent border-neutral-300 text-neutral-500 uppercase text-sm rounded-t-lg'>
							<span>Categorias</span>
						</div>

						<div className='border border-neutral-300 rounded-b-lg'>
							<CustomDataTable columns={columns} data={data} handleAdd={handleAdd} />
						</div>
					</div>

					{showCreateModal && (
						<ModalCreate category={selected} onClose={toggleCreateModal} onCreate={handleCreateCallback} />
					)}

					{showUpdateModal && (
						<ModalUpdate category={selected} onClose={toggleUpdateModal} onUpdate={handleUpdateCallback} />
					)}

					{showDeleteModal && (
						<ModalRemove category={toDelete} onClose={toggleDeleteModal} onRemove={handleDeleteCallback} />
					)}

					{showReactiveModal && (
						<ModalReactive category={selected} onClose={toggleReactiveModal} onReactive={handleReactiveCallback} />
					)}

					<Toaster richColors expand={true} />
				</main>
			</div>
		</>
	)
}

export { CategoryPage }

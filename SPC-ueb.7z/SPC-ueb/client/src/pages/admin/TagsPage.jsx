import { Toaster, toast } from 'sonner'
import { useEffect, useState } from 'react'
import Navbar from '../../components/Navbar'
import { fetch } from '../../services/api/tags.api'
import { formatDate } from '../../utils/dataFormater.utils'
import CustomDataTable from '../../components/table/TableGeneric'
import { BiSolidEditAlt, BiRevision, BiTrashAlt, BiDotsVertical } from 'react-icons/bi'
import { ModalCreate, ModalUpdate, ModalRemove, ModalReactive } from '../../components/form/FormsTag'

const TagsPage = () => {
	const [tags, setTags] = useState([])
	const [menuOpen, setMenuOpen] = useState({})
	const [loading, setLoading] = useState(true)
	const [selected, setSelected] = useState(null)
	const [toDelete, setToDelete] = useState(null)
	const [showUpdateModal, setShowUpdateModal] = useState(false)
	const [showCreateModal, setShowCreateModal] = useState(false)
	const [showDeleteModal, setShowDeleteModal] = useState(false)
	const [showReactiveModal, setShowReactiveModal] = useState(false)

	const toggleMenu = Id => {
		setMenuOpen(prevState => {
			const updatedState = Object.fromEntries(
				Object.entries(prevState).map(([id, isOpen]) => [id, id === Id ? !isOpen : false])
			)
			return {
				...updatedState,
				[Id]: !prevState[Id],
			}
		})
	}

	const handleCloseMenu = () => {
		setMenuOpen({})
	}

	useEffect(() => {
		fetchData()
	}, [])

	const fetchData = async () => {
		try {
			const data = await fetch()
			setTags(data)
			setLoading(false)
		} catch (error) {
			setLoading(false)
			toast.error('Error al cargar etiquetas.')
		}
	}

	const handleAdd = () => {
		setShowCreateModal(true)
	}

	const toggleCreateModal = () => {
		setShowCreateModal(!showCreateModal)
	}

	const handleCreateCallback = async () => {
		try {
			await fetchData()
		} catch (error) {
			toast.error('Error al cargar etiquetas.')
		}
	}

	const handleUpdate = tag => {
		setSelected(tag)
		setShowUpdateModal(true)
	}

	const toggleUpdateModal = () => {
		setShowUpdateModal(!showUpdateModal)
	}

	const handleUpdateCallback = async () => {
		try {
			await fetchData()
		} catch (error) {
			toast.error('Error al cargar etiquetas.')
		}
	}

	const handleDelete = tag => {
		setToDelete(tag)
		setShowDeleteModal(true)
	}

	const toggleDeleteModal = () => {
		setShowDeleteModal(!showDeleteModal)
	}

	const handleDeleteCallback = async () => {
		try {
			await fetchData()
		} catch (error) {
			toast.error('Error al cargar etiquetas.')
		}
	}

	const handleReactive = tag => {
		setSelected(tag)
		setShowReactiveModal(true)
	}

	const toggleReactiveModal = () => {
		setShowReactiveModal(!showReactiveModal)
	}

	const handleReactiveCallback = async () => {
		try {
			await fetchData()
		} catch (error) {
			toast.error('Error al cargar etiquetas.')
		}
	}

	const columns = [
		{
			name: 'Nombre',
			selector: row => row.name,
			sortable: true,
			reorder: true,
			wrap: true,
			maxWidth: '200px',
			format: row => (row.name.length > 60 ? `${row.name.slice(0, 60)}...` : row.name),
		},
		{
			name: 'Descripcion',
			selector: row => row.description,
			sortable: true,
			reorder: true,
			wrap: true,
			maxWidth: '800px',
			format: row => (row.description.length > 60 ? `${row.description.slice(0, 60)}...` : row.description),
		},
		{
			name: 'Estado',
			selector: row => (row.active ? 'Activo' : 'Inactivo'),
			sortable: true,
			reorder: true,
			maxWidth: '0',
			cell: row => (
				<span className={row.active ? 'text-[#009b5d] font-medium' : 'text-[#cd664d] font-medium'}>
					{row.active ? 'Activo' : 'Inactivo'}
				</span>
			),
		},
		{
			name: 'Creado',
			selector: row => row.createdAt,
			sortable: true,
			reorder: true,
			cell: row => <span className='text-xs'>{row.createdAt}</span>,
		},
		{
			name: 'Actualizado',
			selector: row => row.updatedAt,
			sortable: true,
			reorder: true,
			cell: row => <span className='text-xs'>{row.updatedAt}</span>,
		},
		{
			maxWidth: '0',
			cell: tag => (
				<div className='flex gap-2 pl-8'>
					{tag.active ? (
						<>
							<div
								onClick={() => toggleMenu(tag.id)}
								className='hover:bg-neutral-600 bg-neutral-100 hover:text-neutral-50 p-1.5 rounded-lg transition-colors duration-150'>
								<BiDotsVertical />
							</div>

							{menuOpen[tag.id] && (
								<div className='flex flex-col absolute right-16 z-50'>
									<ul className='flex flex-row z-50 border bg-neutral-50 border-neutral-300 rounded-lg text-neutral-500'>
										<li
											onClick={() => {
												handleUpdate(tag)
												handleCloseMenu()
											}}
											className='py-1 px-1.5 hover:bg-neutral-600 hover:text-neutral-50 rounded-l-lg transition-colors duration-150'>
											<span className='flex items-center'>
												<BiSolidEditAlt className='text-base' />
											</span>
										</li>

										<li
											onClick={() => {
												handleDelete(tag)
												handleCloseMenu()
											}}
											className='py-1 px-1.5 border-l border-neutral-300 hover:bg-[#cd664d] hover:text-neutral-50 rounded-r-lg transition-colors duration-150'>
											<span className='flex items-center'>
												<BiTrashAlt className='text-base' />
											</span>
										</li>
									</ul>
								</div>
							)}
						</>
					) : (
						<button
							onClick={() => handleReactive(tag)}
							className='text-emerald-500 hover:text-[#009b5d] hover:bg-emerald-100 bg-emerald-50 border border-emerald-200 p-2 transition-colors duration-200'>
							<BiRevision />
						</button>
					)}
				</div>
			),
		},
	]

	const data = tags.map(tag => ({
		id: tag.id_tag,
		name: tag.name,
		description: tag.description,
		active: tag.active,
		createdAt: formatDate(tag.createdAt),
		updatedAt: formatDate(tag.updatedAt),
	}))

	return (
		<>
			<Navbar />

			<div className='h-screen lg:end-0 lg:start-0 lg:top-0 lg:h-20'>
				<main className='container mx-auto px-4 lg:px-8 xl:max-w-7xl'>
					<div className='py-16'>
						<div className='flex items-center justify-center py-1 mt-4 text-md gap-2 font-semibold bg-neutral-50 border border-b-transparent border-neutral-300 text-neutral-500 uppercase text-sm rounded-t-lg'>
							<span>Etiquetas</span>
						</div>

						<div className='border border-neutral-300'>
							<CustomDataTable columns={columns} data={data} handleAdd={handleAdd} />
						</div>
					</div>

					{showCreateModal && (
						<ModalCreate tag={selected} onClose={toggleCreateModal} onCreate={handleCreateCallback} />
					)}

					{showUpdateModal && (
						<ModalUpdate tag={selected} onClose={toggleUpdateModal} onUpdate={handleUpdateCallback} />
					)}

					{showDeleteModal && (
						<ModalRemove tag={toDelete} onClose={toggleDeleteModal} onRemove={handleDeleteCallback} />
					)}

					{showReactiveModal && (
						<ModalReactive tag={selected} onClose={toggleReactiveModal} onReactive={handleReactiveCallback} />
					)}

					<Toaster richColors expand={true} />
				</main>
			</div>
		</>
	)
}

export { TagsPage }

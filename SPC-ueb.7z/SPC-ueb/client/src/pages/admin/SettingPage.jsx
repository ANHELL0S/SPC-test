import { Toaster, toast } from 'sonner'
import { useEffect, useState } from 'react'
import Navbar from '../../components/Navbar'
import { BiCheck, BiEditAlt } from 'react-icons/bi'
import { fetch, update } from '../../services/api/config.api'

const SettingPage = () => {
	const [editedConfigs, setEditedConfigs] = useState({})
	const [isEditing, setIsEditing] = useState(false)

	const fetchData = async () => {
		try {
			const configsData = await fetch()
			setEditedConfigs(Object.assign({}, ...configsData))
		} catch (error) {
			console.error('Error fetching configs:', error)
		}
	}

	useEffect(() => {
		fetchData()
	}, [])

	const handleInputChange = event => {
		const { name, value } = event.target
		setEditedConfigs({ ...editedConfigs, [name]: value })
	}

	const handleEditClick = () => {
		setIsEditing(!isEditing) // Toggle entre true y false
		toast.info(isEditing ? 'Modo edición desactivado.' : 'Modo edición activado.') // Mensaje según el estado de edición
	}

	const handleSaveClick = async () => {
		try {
			delete editedConfigs.createdAt
			delete editedConfigs.updatedAt
			await update(editedConfigs.id_config, editedConfigs)
			setIsEditing(false)
			fetchData()
			toast.success('Configuración actualizada correctamente.')
		} catch (error) {
			toast.error('Error al actualizar configuraciones.')
		}
	}

	return (
		<>
			<Navbar />
			<div className='h-screen lg:end-0 lg:start-0 lg:top-0 lg:h-20'>
				<main className='container mx-auto px-4 lg:px-8 xl:max-w-7xl'>
					<div className='lg:py-20 sm:py-10'>
						<div className='flex flex-col bg-white active:border-neutral-300 lg:col-span-3'>
							<div className='flex items-center justify-between gap-2 text-md bg-white border border-neutral-300 text-neutral-500 pl-6 my-2'>
								<div className='flex flex-row items-center gap-2 font-semibold'>
									<span>{isEditing ? 'Modo edición' : 'Configuraciones'}</span>
								</div>

								{isEditing ? (
									<button
										onClick={handleSaveClick}
										className='flex flex-row gap-1 items-center bg-sky-200 hover:bg-neutral-600 border-l border-neutral-300 text-neutral-700 hover:text-neutral-50 px-3 py-2 transition-colors duration-200 hover:underline'>
										<BiCheck className='text-lg' />
									</button>
								) : (
									<button
										onClick={handleEditClick}
										className='flex flex-row gap-1 items-center bg-neutral-50 hover:bg-neutral-100 border-l border-neutral-300 hover:text-neutral-700 px-3 py-2 transition-colors duration-200 hover:underline'>
										<BiEditAlt className='text-lg' />
									</button>
								)}
							</div>
						</div>

						<div className='bg-white border border-neutral-300 p-6'>
							<div>
								<form>
									<div className='grid grid-cols-1 md:grid-cols-3 gap-6'>
										{Object.keys(editedConfigs).map(key => {
											if (key !== 'createdAt' && key !== 'updatedAt') {
												if (key === 'id_config') {
													return null
												} else {
													return (
														<div key={key} className='mb-4'>
															<label className='block text-neutral-500 text-sm font-medium mb-2' htmlFor={key}>
																{key === 'name_institution'
																	? 'Nombre de la Institución'
																	: key === 'abbreviation'
																	? 'Abreviatura'
																	: key === 'slogan'
																	? 'Eslogan'
																	: key === 'link_fb'
																	? 'Enlace de Facebook'
																	: key === 'link_ig'
																	? 'Enlace de Instagram'
																	: key === 'link_yt'
																	? 'Enlace de YouTube'
																	: key === 'link_x'
																	? 'Enlace X'
																	: key}
															</label>

															<input
																type='text'
																id={key}
																name={key}
																value={editedConfigs[key]}
																onChange={handleInputChange}
																className='text-neutral-500 text-sm font-medium appearance-none border border-neutral-300 w-full py-2 px-3 focus:outline-none focus:border-neutral-400'
																readOnly={!isEditing}
															/>
														</div>
													)
												}
											} else {
												return null
											}
										})}
									</div>
								</form>
							</div>
						</div>
					</div>
					<Toaster richColors expand={true} />
				</main>
			</div>
		</>
	)
}

export { SettingPage }

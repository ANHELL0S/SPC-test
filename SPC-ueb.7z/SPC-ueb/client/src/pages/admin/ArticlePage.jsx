import { Toaster, toast } from 'sonner'
import { useEffect, useState } from 'react'
import Navbar from '../../components/Navbar'
import { formatDate } from '../../utils/dataFormater.utils'
import { Sub_header } from '../../components/ui/Sub_header.UI'
import { ModalRemove } from '../../components/form/FormsArticle'
import { SearchInput } from '../../components/ui/Search_Input.UI'
import { fetch, check, remove as removeArticle } from '../../services/api/article.api'
import {
	BiBookmark,
	BiCalendarAlt,
	BiCheck,
	BiEditAlt,
	BiFoodMenu,
	BiMessageSquareDetail,
	BiShow,
	BiTrashAlt,
	BiUser,
	BiX,
} from 'react-icons/bi'
import {
	create,
	get_approved,
	get_pending,
	remove,
	check_review,
	uncheck_review,
	update,
} from '../../services/api/reviews.api'
import { Spinner } from '../../components/ui/spinner'

const ArticlePage = () => {
	const [loading, setLoading] = useState(true)
	const [articles, setArticles] = useState([])
	const [selectedArticle, setSelectedArticle] = useState(null)
	const [isDetailModalOpen, setIsDetailModalOpen] = useState(false)
	const [isReviewModalOpen, setIsReviewModalOpen] = useState(false)
	const [reviewContent, setReviewContent] = useState('')
	const [reviewsApproved, setReviewsApproved] = useState([])
	const [reviewsPending, setReviewsPending] = useState([])
	const [searchTerm, setSearchTerm] = useState('')
	const [editingReviewId, setEditingReviewId] = useState(null)
	const [editedTask, setEditedTask] = useState('')
	const [toDelete, setToDelete] = useState(null)
	const [showDeleteModal, setShowDeleteModal] = useState(false)
	const [processingArticleId, setProcessingArticleId] = useState(null)

	const openEditModal = (reviewId, task) => {
		setEditingReviewId(reviewId)
		setEditedTask(task)
	}

	const closeEditModal = () => {
		setEditingReviewId(null)
		setEditedTask('')
	}

	useEffect(() => {
		fetchData()
	}, [])

	const fetchData = async () => {
		try {
			const articlesData = await fetch()
			setArticles(articlesData)
			setLoading(false)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const openDetailModal = article => {
		setSelectedArticle(article)
		setIsDetailModalOpen(true)
	}

	const openReviewModal = async article => {
		setSelectedArticle(article)
		setIsReviewModalOpen(true)
		setReviewsApproved([]) // Limpiar el estado
		setReviewsPending([]) // Limpiar el estado

		try {
			const approvedData = await get_approved(article.id_article)
			const pendingData = await get_pending(article.id_article)
			setReviewsApproved(approvedData)
			setReviewsPending(pendingData)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const closeDetailModal = () => {
		setSelectedArticle(null)
		setIsDetailModalOpen(false)
	}

	const closeReviewModal = () => {
		setSelectedArticle(null)
		setIsReviewModalOpen(false)
	}

	const handleSubmitReview = async () => {
		try {
			const response = await create({ articleId: selectedArticle.id_article, content: reviewContent })
			toast.success(`${response.message}`)
			setReviewContent('')
			fetchReviews()
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}
	const handle_check_article = async id => {
		setProcessingArticleId(id) // Establecer el estado de carga
		try {
			const response = await check(id)
			toast.success(`${response.message}`)
			fetchData()
		} catch (error) {
			toast.error(`${error.message}`)
		} finally {
			setProcessingArticleId(null) // Restablecer el estado de carga
		}
	}

	const fetchReviews = async () => {
		try {
			const approved = await get_approved(selectedArticle.id_article)
			const pending = await get_pending(selectedArticle.id_article)
			setReviewsApproved(approved)
			setReviewsPending(pending)
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const handleDeleteReview = async reviewId => {
		try {
			const response = await remove(reviewId)
			toast.success(`${response.message}`)
			fetchReviews()
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const handle_check_review = async id => {
		try {
			const response = await check_review(id)
			toast.success(`${response.message}`)
			fetchReviews()
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const handle_unCheck_review = async id => {
		try {
			const response = await uncheck_review(id)
			toast.success(`${response.message}`)
			fetchReviews()
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const handleEditReview = async () => {
		try {
			const response = await update(editingReviewId, { task: editedTask })
			toast.success(`${response.message}`)
			fetchReviews()
			closeEditModal()
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const handleDelete = article => {
		setToDelete(article)
		setShowDeleteModal(true)
	}

	const toggleDeleteModal = () => {
		setShowDeleteModal(!showDeleteModal)
	}

	const handleDeleteCallback = async () => {
		try {
			await fetchData()
		} catch (error) {
			toast.error('Error al cargar articulos.')
		}
	}

	const filtered_articles = articles.filter(articles => articles.title.toLowerCase().includes(searchTerm.toLowerCase()))

	return (
		<>
			<Navbar />

			<div className='h-screen lg:end-0 lg:start-0 lg:top-0 lg:h-20'>
				<main className='container mx-auto px-4 lg:px-8 xl:max-w-7xl'>
					<div className='md:py-2 lg:py-20 transform transition-all'>
						<Sub_header title='Articulos' itemCount={articles.length} />
						<div className='flex gap-4 py-4 justify-end'>
							<SearchInput onSearch={setSearchTerm} />
						</div>

						{loading ? (
							<Spinner />
						) : (
							<div className='grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3 text-sm text-neutral-600'>
								{filtered_articles.map(article => (
									<div
										key={article.id_article}
										className='max-w-sm overflow-hidden border border-neutral-300 rounded-lg'>
										<div className='px-4 py-2 flex justify-between items-center border-b border-neutral-300 bg-neutral-50'>
											<span className='font-semibold overflow-hidden overflow-ellipsis whitespace-nowrap'>
												{article.title}
											</span>
										</div>

										<div className='px-4 py-3 flex flex-col gap-1 text-neutral-500 text-xs font-medium'>
											<div className='flex flex-row items-center gap-1'>
												<BiUser />
												<span>Subido por {article.manager_name}</span>
											</div>

											<div className='flex flex-row items-center gap-1'>
												<BiCalendarAlt />
												<span>Subido {formatDate(article.createdAt)}</span>
											</div>

											<div className='flex flex-row items-center gap-1'>
												<BiFoodMenu />
												<span>{article.category_name}</span>
											</div>

											<div className='flex flex-row items-center gap-1'>
												<BiMessageSquareDetail />
												<span>
													{article.comment_count} {article.comment_count === 1 ? 'comentario' : 'comentarios'}
												</span>
											</div>

											<div className='flex flex-row items-center gap-1'>
												<BiBookmark />
												<span>
													{article.collection_count} {article.collection_count === 1 ? 'colección' : 'colecciones'}
												</span>
											</div>
										</div>

										<div className='border-t border-neutral-300 flex flex-row items-center justify-between'>
											<div
												onClick={() => handle_check_article(article.id_article)}
												className={`flex items-center px-4 py-1 text-xs text-white rounded-bl-lg cursor-pointer ${
													article.status === 'pendiente' ? 'bg-orange-700' : 'bg-green-700'
												}`}>
												<span>{processingArticleId === article.id_article ? 'Procesando...' : article.status}</span>
											</div>

											<div className='flex'>
												<div
													onClick={() => openReviewModal(article)}
													className='flex items-center border-l border-neutral-300 cursor-pointer py-1.5 px-2 hover:bg-neutral-600 hover:text-neutral-50 transition-colors duration-150'>
													<BiMessageSquareDetail />
												</div>

												<div
													onClick={() => openDetailModal(article)}
													className='flex items-center border-l border-neutral-300 cursor-pointer py-1.5 px-2 hover:bg-neutral-600 hover:text-neutral-50 transition-colors duration-150'>
													<BiShow />
												</div>

												<div
													onClick={() => handleDelete(article)}
													className='flex items-center border-l border-neutral-300 cursor-pointer py-1.5 px-2 rounded-br-lg hover:bg-red-700 hover:text-neutral-50 transition-colors duration-150'>
													<BiTrashAlt />
												</div>
											</div>
										</div>
									</div>
								))}
							</div>
						)}
					</div>
				</main>
			</div>

			{selectedArticle && isDetailModalOpen && (
				<div className='fixed z-50 inset-0 bg-neutral-50 overflow-y-auto py-4'>
					<div className='flex items-end justify-center min-h-screen px-4 text-center sm:block sm:p-0'>
						<div className='sm:inline-block sm:h-screen lg:h-screen align-bottom bg-neutral-50 text-left transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full'>
							<div
								className={`flex items-center justify-between gap-2 text-sm rounded-t-lg text-neutral-600 font-medium border border-neutral-300 pl-4 w-full`}>
								<span className='flex flex-row items-center'>
									<span>Detalles del artículo</span>
								</span>

								<button
									type='button'
									onClick={closeDetailModal}
									className={`flex flex-row items-center py-2 px-2 rounded-tr-lg text-neutral-600 hover:text-neutral-50 bg-neutral-100 hover:bg-[#cd664d] border-l border-neutral-300 transition-colors duration-200`}>
									<BiX />
								</button>
							</div>

							<div className='w-full'>
								<div className='sm:flex sm:items-start'>
									<div className='text-neutral-600 w-full'>
										<div className='border border-t-transparent border-b-transparent border-neutral-300 rounded-b-lg w-full'>
											<div className='flex flex-col'>
												<div className='text-xs border-b border-neutral-300 px-4 py-2'>
													<h4 className='font-semibold text-xs mb-2'>Título</h4>
													<span>{selectedArticle.title}</span>
												</div>

												<div className='text-xs border-b border-neutral-300 px-4 py-2'>
													<h4 className='font-semibold text-xs mb-2'>Resumen</h4>
													<span>{selectedArticle.summary}</span>
												</div>

												<div className='text-xs border-b border-neutral-300 rounded-b-lg px-4 py-2'>
													<h4 className='font-semibold text-xs mb-2'>Link</h4>
													<a href={selectedArticle.link} className='hover:underline text-sky-600 hover:text-sky-800'>
														{selectedArticle.link}
													</a>
												</div>
											</div>
										</div>

										<div className='mt-4 flex items-center justify-between gap-2 text-sm rounded-t-lg text-neutral-600 font-medium border border-neutral-300 px-4 py-1.5 w-full'>
											<span className='flex flex-row items-center'>
												<span>Parámetros</span>
											</span>
										</div>

										<div className='border rounded-b-lg border-t-transparent border-neutral-300 px-4 py-2 w-full'>
											<ul className='text-xs'>
												{selectedArticle.parameters.map(parameter => (
													<li key={parameter.id_parameter} className='flex flex-row gap-2 py-1 text-neutral-500'>
														<span className='font-semibold'>{parameter.name_parameter}:</span>
														<span>{parameter.description_parameter}</span>
													</li>
												))}
											</ul>
										</div>

										<div className='mt-4 flex items-center justify-between gap-2 text-sm rounded-t-lg text-neutral-600 font-medium border border-neutral-300 px-4 py-1.5 w-full'>
											<span className='flex flex-row items-center'>
												<span>Etiquetas</span>
											</span>
										</div>

										<div className='border rounded-b-lg border-t-transparent border-neutral-300 px-4 py-2 w-full'>
											<ul className='text-xs'>
												{selectedArticle.tags.length > 0 ? (
													selectedArticle.tags.map(tag => (
														<li key={tag.id_tag} className='flex flex-row gap-2 py-1 text-neutral-500'>
															<span className='font-semibold'>{tag.name_tag}:</span>
															<span>{tag.description_tag}</span>
														</li>
													))
												) : (
													<p>No hay etiquetas asociadas a este artículo.</p>
												)}
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			)}

			{selectedArticle && isReviewModalOpen && (
				<div className='fixed z-50 inset-0 bg-neutral-50 overflow-y-auto py-4'>
					<div className='flex items-end justify-center min-h-screen px-4 text-center sm:block sm:p-0'>
						<div className='sm:inline-block sm:h-screen lg:h-screen align-bottom bg-neutral-50 text-left transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full'>
							<div className='flex items-center justify-between text-sm border rounded-t-lg border-neutral-300 text-neutral-700 font-semibold pl-4'>
								<span>Revisiones</span>

								<button
									onClick={closeReviewModal}
									type='button'
									className='flex items-center justify-center p-1.5 rounded-tr-lg border-l border-neutral-300 text-neutral-600 hover:text-neutral-50 bg-neutral-100 hover:bg-[#cd664d] transition-colors duration-200'>
									<BiX size={18} />
								</button>
							</div>

							<div className='border border-t-transparent border-neutral-300 rounded-b-lg'>
								<textarea
									value={reviewContent}
									onChange={e => setReviewContent(e.target.value)}
									className='border-b border-neutral-300 bg-neutral-50 p-4 focus:outline-none focus:border-primary-500 w-full text-sm text-neutral-600'
									rows={3}
									placeholder='Ingresa la revisión...'></textarea>

								<div className='flex justify-end text-sm'>
									<button
										onClick={handleSubmitReview}
										className='px-3 py-1 bg-primary-500 text-neutral-600 hover:bg-sky-600 hover:text-neutral-50 bg-neutral-100 border-l border-neutral-300 hover:bg-primary-600 focus:outline-none focus:bg-primary-600 transition-colors duration-200 rounded-br-lg'>
										Ok, crear
									</button>
								</div>
							</div>

							<div className='text-neutral-600 text-sm border rounded-t-lg border-b px-4 py-1.5 border-neutral-300 mt-4'>
								<h3 className='text-md font-semibold'>Revisiones aprobadas ({reviewsApproved.length})</h3>
							</div>

							<div className='text-neutral-600 text-sm border border-t-transparent rounded-b-lg px-4 py-1 border-neutral-300'>
								<div className='max-h-40 overflow-y-auto'>
									{reviewsApproved.length === 0 ? (
										<p className='text-neutral-400 text-xs'>No hay revisiones aprobadas</p>
									) : (
										<ul className='space-y-2'>
											{reviewsApproved.map(review => (
												<li key={review.id_review} className='flex justify-between items-center'>
													<div className='flex flex-col'>
														<span className='text-xs text-neutral-400'>{formatDate(review.createdAt)}</span>
														<span className='line-through text-sm'>{review.task}</span>
													</div>

													<button
														onClick={() => handle_unCheck_review(review.id_review)}
														className='hover:text-red-700 hover:bg-red-100 p-1 rounded-lg transition-colors duration-150 border border-neutral-300'>
														<BiX size={14} />
													</button>
												</li>
											))}
										</ul>
									)}
								</div>
							</div>

							<div className='text-neutral-600 text-sm border rounded-t-lg border-b px-4 py-1.5 border-neutral-300 mt-4'>
								<h3 className='text-md font-semibold'>Revisiones pendientes ({reviewsPending.length})</h3>
							</div>

							<div className='text-neutral-600 text-sm border border-t-transparent rounded-b-lg px-4 py-1 border-neutral-300'>
								<div className='max-h-40 overflow-y-auto'>
									{reviewsPending.length === 0 ? (
										<p className='text-neutral-400 text-xs'>No hay revisiones pendientes</p>
									) : (
										<ul className='space-y-2'>
											{reviewsPending.map(review => (
												<li key={review.id_review} className='flex justify-between items-center'>
													<div className='flex flex-col'>
														<span className='text-xs text-neutral-400'>{formatDate(review.createdAt)}</span>
														<span className='text-sm'>{review.task}</span>
													</div>

													<div className='flex text-neutral-400 border border-neutral-300 rounded-lg'>
														<button
															onClick={() => handleDeleteReview(review.id_review)}
															className='hover:text-red-700 hover:bg-red-100 p-1 rounded-l-lg transition-colors duration-150'>
															<BiTrashAlt size={14} />
														</button>

														<button
															onClick={() => openEditModal(review.id_review, review.task)}
															className='hover:text-sky-700 hover:bg-sky-100 p-1 transition-colors duration-150 border-l border-neutral-300'>
															<BiEditAlt size={14} />
														</button>

														{editingReviewId && (
															<div className='fixed inset-0 z-50 overflow-y-auto flex justify-center items-center bg-neutral-50 text-neutral-600'>
																<div className='bg-neutral-50 w-full max-w-sm rounded-lg border border-neutral-300'>
																	<h2 className='text-md font-semibold px-4 py-1.5'>Editar revisión</h2>

																	<textarea
																		type='text'
																		value={editedTask}
																		onChange={e => setEditedTask(e.target.value)}
																		className='border-b border-t bg-neutral-50 border-neutral-300 px-2 py-1 focus:outline-none focus:border-primary-500 w-full text-sm text-neutral-600'
																		rows={3}
																		placeholder='Editar revisión...'></textarea>

																	<div className='flex justify-end'>
																		<button
																			onClick={closeEditModal}
																			className='px-3 py-1 bg-neutral-100 text-neutral-500 hover:bg-red-400 hover:text-neutral-50 focus:outline-none focus:bg-neutral-400 border-l border-r border-neutral-300 transition-colors duration-200'>
																			No, cancelar
																		</button>

																		<button
																			onClick={handleEditReview}
																			className='px-3 py-1 bg-primary-500 text-white bg-sky-600 hover:bg-sky-700 border-transparent hover:bg-primary-600 focus:outline-none focus:bg-primary-600 transition-colors rounded-br-lg duration-200'>
																			Ok, guardar
																		</button>
																	</div>
																</div>
															</div>
														)}

														<button
															onClick={() => handle_check_review(review.id_review)}
															className='hover:text-green-700 hover:bg-green-100 p-1 rounded-r-lg transition-colors duration-150 border-l border-neutral-300'>
															<BiCheck size={14} />
														</button>
													</div>
												</li>
											))}
										</ul>
									)}
								</div>
							</div>
						</div>
					</div>
				</div>
			)}

			{showDeleteModal && (
				<ModalRemove article={toDelete} onClose={toggleDeleteModal} onRemove={handleDeleteCallback} />
			)}

			<Toaster richColors expand={true} />
		</>
	)
}

export { ArticlePage }

import { Toaster, toast } from 'sonner'
import { useEffect, useState } from 'react'
import Navbar from '../../components/Navbar'
import { formatDate } from '../../utils/dataFormater.utils'
import { Sub_header } from '../../components/ui/Sub_header.UI'
import { SearchInput } from '../../components/ui/Search_Input.UI'
import { fetch as fetchTemplate, removeTags } from '../../services/api/template.api'
import { ModalAdd, ModalRemove, ModalUpdate } from '../../components/form/FormsTemplate'
import { BiBookmarks, BiCalendarAlt, BiDotsVertical, BiPlus, BiTrashAlt, BiX } from 'react-icons/bi'
import { Spinner } from '../../components/ui/spinner'

// Loading Component
const Loading = () => (
	<div className='flex items-center justify-center w-full h-full col-span-12'>
		<Spinner />
	</div>
)

const TemplatePage = () => {
	const [templates, setTemplates] = useState([])
	const [showCreateModal, setShowCreateModal] = useState(false)
	const [showRemoveModal, setShowRemoveModal] = useState(false)
	const [toRemove, setToRemove] = useState(null)
	const [selectedTags, setSelectedTags] = useState([])
	const [showTagDetailsModal, setShowTagDetailsModal] = useState(false)
	const [updateModalOpen, setUpdateModalOpen] = useState(false)
	const [menuOpen, setMenuOpen] = useState({})
	const [selectedCategory, setSelectedCategory] = useState(null)
	const [searchTerm, setSearchTerm] = useState('')
	const [loading, setLoading] = useState(true)

	const toggleMenu = Id => {
		setMenuOpen(prevState => {
			const updatedState = Object.fromEntries(
				Object.entries(prevState).map(([id_category_fk, isOpen]) => [
					id_category_fk,
					id_category_fk === Id ? !isOpen : false,
				])
			)
			return {
				...updatedState,
				[Id]: !prevState[Id],
			}
		})
	}

	const handleCloseMenu = () => {
		setMenuOpen({})
	}

	useEffect(() => {
		fetchData()
	}, [])

	const fetchData = async () => {
		setLoading(true)
		try {
			const data = await fetchTemplate()
			setTemplates(data)
		} catch (error) {
			toast.error('Error al cargar los formatos.')
		} finally {
			setLoading(false)
		}
	}

	const handleAdd = () => {
		setShowCreateModal(true)
	}

	const handleCloseModal = () => {
		setShowCreateModal(false)
	}

	const handleCreateCallback = async () => {
		try {
			await fetchData()
		} catch (error) {
			toast.error('Error al cargar los formatos.')
		}
	}

	const handleRemove = template => {
		setToRemove(template)
		setShowRemoveModal(true)
	}

	const toggleRemoveModal = () => {
		setShowRemoveModal(!showRemoveModal)
	}

	const handleRemoveCallback = async () => {
		try {
			await fetchData()
			setToRemove(null)
		} catch (error) {
			toast.error('Error al cargar los formatos.')
		}
	}

	const handleCloseTagDetailsModal = () => {
		setShowTagDetailsModal(false)
	}

	const handleShowTagDetails = template => {
		setSelectedTags(template.tags)
		setSelectedCategory({ categoryId: template.id_category_fk, categoryName: template.categoryName })
		setShowTagDetailsModal(true)
	}

	const handleUpdate = template => {
		setSelectedCategory(template.id_template)
		setUpdateModalOpen(true)
		const tagsOfSelectedTemplate = template.tags
		setSelectedTags(tagsOfSelectedTemplate)
	}

	const handleUpdateCallback = async () => {
		try {
			await fetchData()
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const handleTagDelete = async id_relation_tag_template => {
		try {
			const response = await removeTags(id_relation_tag_template)

			const updatedTags = selectedTags.filter(tag => tag.id_relation_tag_template !== id_relation_tag_template)
			setSelectedTags(updatedTags)

			toast.success(`${response.message}`)

			await fetchData()
		} catch (error) {
			toast.error(`${error.message}`)
		}
	}

	const filtered_template = templates.filter(template =>
		template.category_name.toLowerCase().includes(searchTerm.toLowerCase())
	)

	return (
		<>
			<Navbar />

			<div className='h-screen lg:end-0 lg:start-0 lg:top-0 lg:h-20'>
				<main className='container mx-auto px-4 lg:px-8 xl:max-w-7xl'>
					<div className='md:py-2 lg:py-20 transform transition-all'>
						<Sub_header title='Formatos' itemCount={templates.length} />

						<div className='flex items-center justify-between gap-2 text-md bg-white text-neutral-500 py-3'>
							<div className='flex gap-4'>
								<div
									onClick={handleAdd}
									className='flex flex-row items-center text-sm gap-1 px-2.5 py-2 rounded-lg bg-neutral-600 text-white cursor-pointer hover:bg-neutral-700 transition-colors duration-150'>
									<BiPlus />
								</div>
							</div>

							<div className='flex gap-4'>
								<SearchInput onSearch={setSearchTerm} />
							</div>
						</div>

						<div className='grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-12 lg:gap-x-8'>
							{loading ? (
								<Loading />
							) : (
								filtered_template.map((template, index) => (
									<div key={index} className='flex flex-col bg-white active:border-neutral-300 lg:col-span-3'>
										<div className='flex items-center justify-between gap-2 text-sm bg-white border border-neutral-300 text-neutral-500 pl-4 rounded-t-lg border-b-transparent'>
											<div className='flex flex-row items-center gap-2 font-medium'>
												<span className='text-xs font-semibold uppercase text-neutral-500'>
													{template.category_name}
												</span>
											</div>

											<div
												className='bg-neutral-50 border-l rounded-tr-lg hover:bg-neutral-600 hover:text-neutral-50 border-neutral-300 p-2 relative cursor-pointer transition-colors duration-150'
												onClick={() => toggleMenu(template.id_category_fk)}>
												<BiDotsVertical />

												{menuOpen[template.id_category_fk] && (
													<div className='flex flex-col absolute right-8 top-0 mt-0 z-10'>
														<ul className='flex flex-row text-neutral-500 bg-transparent'>
															<li>
																<button
																	className='hover:text-neutral-700 hover:bg-neutral-100 flex items-center gap-2 transition-colors duration-200 p-2 border-l border-neutral-300'
																	onClick={() => {
																		handleUpdate(template)
																		handleCloseMenu()
																	}}>
																	<BiPlus className='text-base' />
																</button>
															</li>

															<li>
																<button
																	onClick={() => {
																		handleShowTagDetails(template)
																		handleCloseMenu()
																	}}
																	className='hover:text-neutral-700 hover:bg-neutral-100 flex items-center gap-2 transition-colors duration-200 p-2 border-l border-neutral-300'>
																	<BiBookmarks className='text-base' />
																</button>
															</li>

															<li>
																<button
																	onClick={() => {
																		handleRemove(template)
																		handleCloseMenu()
																	}}
																	className='hover:text-neutral-50 hover:bg-[#e06b4f] flex items-center gap-2 transition-colors duration-200 p-2 text-neutral-500 border-l border-neutral-300'>
																	<BiTrashAlt className='text-base' />
																</button>
															</li>
														</ul>
													</div>
												)}
											</div>
										</div>

										<div className='flex grow items-center justify-between p-4 border border-neutral-300'>
											<div className='flex flex-col gap-2 text-xs font-medium text-neutral-500'>
												<div className='flex flex-row items-center gap-1'>
													<BiBookmarks />
													<span>{template.tags.length} etiquetas</span>
												</div>

												<div className='flex flex-row items-center gap-1'>
													<BiCalendarAlt />
													<span>{formatDate(template.createdAt)}</span>
												</div>
											</div>
										</div>
									</div>
								))
							)}
						</div>
					</div>

					{showCreateModal && <ModalAdd onClose={handleCloseModal} onCreate={handleCreateCallback} />}

					{showRemoveModal && (
						<ModalRemove template={toRemove} onClose={toggleRemoveModal} onRemove={handleRemoveCallback} />
					)}

					{showTagDetailsModal && (
						<div className='fixed inset-0 z-50 overflow-y-auto flex justify-center items-center bg-neutral-50 border border-neutral-300'>
							<div>
								<div className='flex items-center justify-between gap-2 text-md text-neutral-500 font-medium border border-neutral-300 pl-4 rounded-t-lg'>
									<span className='flex flex-row items-center'>
										<span>Etiquetas</span>
									</span>

									<button
										type='button'
										onClick={handleCloseTagDetailsModal}
										className='lex flex-row items-center py-2 px-2 text-neutral-600 hover:text-neutral-50 bg-neutral-100 hover:bg-[#cd664d] border-l border-neutral-300 transition-colors duration-200 rounded-tr-lg'>
										<BiX />
									</button>
								</div>

								<ul className='flex flex-col pl-4 min-w-72 border border-neutral-300 border-t-transparent'>
									{selectedTags.map(tag => (
										<div
											key={tag.id_relation_tag_template}
											className='flex items-center justify-between gap-2 text-md text-neutral-500 font-medium'>
											<div className='flex flex-row items-center'>
												<span>{tag.tag_name}</span>
											</div>

											<button
												onClick={() => handleTagDelete(tag.id_relation_tag_template)}
												className='lex flex-row items-center py-2 px-2 text-neutral-600 hover:text-neutral-50 bg-neutral-100 hover:bg-[#cd664d] transition-colors duration-200 border-l border-neutral-300'>
												<BiX />
											</button>
										</div>
									))}
								</ul>
							</div>
						</div>
					)}

					{updateModalOpen && (
						<ModalUpdate
							onClose={() => setUpdateModalOpen(false)}
							onUpdate={handleUpdateCallback}
							template={{ id_template: selectedCategory, tags: selectedTags }}
						/>
					)}

					<Toaster richColors expand={true} />
				</main>
			</div>
		</>
	)
}

export { TemplatePage }

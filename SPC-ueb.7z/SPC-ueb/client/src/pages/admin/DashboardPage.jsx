import { Link } from 'react-router-dom'
import { useEffect, useState } from 'react'
import Navbar from '../../components/Navbar'
import { useAuth } from '../../context/AuthContext'
import { formatDate } from '../../utils/dataFormater.utils'
import { fetch as fetchTags } from '../../services/api/tags.api'
import { fetch as fetchUsers } from '../../services/api/users.api'
import { fetch as fetchMovements } from '../../services/api/movements.api'
import { fetch as fetchCategories } from '../../services/api/categories.api'
import { BiArchive, BiBookmarks, BiFoodMenu, BiRightArrowAlt, BiUser } from 'react-icons/bi'

const DashboardPage = () => {
	const { user } = useAuth()
	const [loading, setLoading] = useState(true)
	const [movements, setMovements] = useState([])
	const [totalUsers, setTotalUsers] = useState(0)
	const [totalCategories, setTotalCategories] = useState(0)
	const [totalTags, setTotalTags] = useState(0)
	const [inactiveUsersCount, setInactiveUsersCount] = useState(0)
	const [inactiveCategoryCount, setInactiveCategoryCount] = useState(0)
	const [inactiveTagsCount, setInactiveTagsCount] = useState(0)

	useEffect(() => {
		fetchData()
		fetchGlobalInfo()
	}, [])

	const fetchData = async () => {
		try {
			setLoading(true) // Indica que se está cargando
			const movementsData = await fetchMovements()
			movementsData.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
			setMovements(movementsData)
		} catch (error) {
			console.error('Error fetching movements:', error)
		} finally {
			setLoading(false) // Indica que se ha completado la carga
		}
	}

	const fetchGlobalInfo = async () => {
		try {
			setLoading(true) // Indica que se está cargando
			const usersData = await fetchUsers()
			const inactiveUsers = usersData.filter(user => !user.active)
			setTotalUsers(usersData.length)
			setInactiveUsersCount(inactiveUsers.length)

			const categoriesData = await fetchCategories()
			const inactiveCategory = categoriesData.filter(category => !category.active)
			setTotalCategories(categoriesData.length)
			setInactiveCategoryCount(inactiveCategory.length)

			const tagsData = await fetchTags()
			const inactiveTags = tagsData.filter(tags => !tags.active)
			setTotalTags(tagsData.length)
			setInactiveTagsCount(inactiveTags.length)
		} catch (error) {
			console.error('Error fetching global info:', error)
		} finally {
			setLoading(false) // Indica que se ha completado la carga
		}
	}

	const groupMovementsByTargetType = () => {
		const groupedMovements = {}
		movements.forEach(movement => {
			if (!groupedMovements[movement.targetType]) {
				groupedMovements[movement.targetType] = []
			}
			if (groupedMovements[movement.targetType].length < 2) {
				groupedMovements[movement.targetType].push(movement)
			}
		})
		return groupedMovements
	}

	return (
		<>
			<Navbar />

			<div className='h-screen lg:end-0 lg:start-0 lg:top-0 lg:h-20'>
				<main className='container mx-auto px-4 lg:px-8 xl:max-w-7xl'>
					<div className='sm:py-0 lg:py-16'>
						<div className='flex flex-col gap-2 text-center sm:flex-row sm:items-center sm:justify-between sm:text-start'>
							<div className='grow py-8'>
								<h1 className='mb-1 text-xl font-semibold text-neutral-600'>Bienvenido, {user.username} 👋</h1>
							</div>
						</div>

						<div className='grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-12 lg:gap-8'>
							<div className='flex flex-col bg-white active:border-neutral-300 lg:col-span-3'>
								<div className='flex items-center justify-between gap-2 text-sm bg-white border border-neutral-300 text-neutral-500 pl-4 border-b-transparent rounded-t-lg'>
									<span className='text-xs font-semibold uppercase text-neutral-500'>Usuarios</span>

									<Link
										to='/dashboard/usuarios'
										className='flex flex-row gap-1 items-center bg-neutral-50 hover:bg-neutral-600 border-l border-neutral-300 hover:text-neutral-50 px-2 py-1 transition-colors duration-200 hover:underline rounded-tr-lg'>
										<BiRightArrowAlt className='text-lg' />
									</Link>
								</div>

								<div className='flex grow items-center justify-between p-4 border border-neutral-300 rounded-b-lg'>
									<div className='flex flex-col'>
										<span className='text-2xl font-semibold text-neutral-500 mb-1'>{totalUsers}</span>
										<span className='text-xs font-medium text-[#cd664d]'>{inactiveUsersCount} Inactivos</span>
									</div>

									<div className='flex items-center text-sm font-medium text-neutral-400 p-2'>
										<BiUser className='hi-outline hi-server inline-block size-10' />
									</div>
								</div>
							</div>

							<div className='flex flex-col bg-white active:border-neutral-300 lg:col-span-3'>
								<div className='flex items-center justify-between gap-2 text-sm bg-white border border-neutral-300 text-neutral-500 pl-4 border-b-transparent rounded-t-lg'>
									<span className='text-xs font-semibold uppercase text-neutral-500'>Categorias</span>

									<Link
										to='/dashboard/categorias'
										className='flex flex-row gap-1 items-center bg-neutral-50 hover:bg-neutral-600 border-l border-neutral-300 hover:text-neutral-50 px-2 py-1 transition-colors duration-200 hover:underline rounded-tr-lg'>
										<BiRightArrowAlt className='text-lg' />
									</Link>
								</div>

								<div className='flex grow items-center justify-between p-4 border border-neutral-300 rounded-b-lg'>
									<div className='flex flex-col'>
										<span className='text-2xl font-semibold text-neutral-500 mb-1'>{totalCategories}</span>
										<span className='text-xs font-medium text-[#cd664d]'>{inactiveCategoryCount} Inactivos</span>
									</div>

									<div className='flex items-center text-sm font-medium text-neutral-400 p-2'>
										<BiFoodMenu className='hi-outline hi-server inline-block size-10' />
									</div>
								</div>
							</div>

							<div className='flex flex-col bg-white active:border-neutral-300 lg:col-span-3'>
								<div className='flex items-center justify-between gap-2 text-sm bg-white border border-neutral-300 text-neutral-500 pl-4 border-b-transparent rounded-t-lg'>
									<span className='text-xs font-semibold uppercase text-neutral-500'>Etiquetas</span>

									<Link
										to='/dashboard/etiquetas'
										className='flex flex-row gap-1 items-center bg-neutral-50 hover:bg-neutral-600 border-l border-neutral-300 hover:text-neutral-50 px-2 py-1 transition-colors duration-200 hover:underline rounded-tr-lg'>
										<BiRightArrowAlt className='text-lg' />
									</Link>
								</div>

								<div className='flex grow items-center justify-between p-4 border border-neutral-300 rounded-b-lg'>
									<div className='flex flex-col'>
										<span className='text-2xl font-semibold text-neutral-500 mb-1'>{totalTags}</span>
										<span className='text-xs font-medium text-[#cd664d]'>{inactiveTagsCount} Inactivos</span>
									</div>

									<div className='flex items-center text-sm font-medium text-neutral-400 p-2'>
										<BiBookmarks className='hi-outline hi-server inline-block size-10' />
									</div>
								</div>
							</div>

							<div className='flex flex-col bg-white active:border-neutral-300 lg:col-span-3'>
								<div className='flex items-center justify-between gap-2 text-sm bg-white border border-neutral-300 text-neutral-500 pl-4 border-b-transparent rounded-t-lg'>
									<span className='text-xs font-semibold uppercase text-neutral-500'>Articulos</span>

									<Link
										to='/dashboard/articulos'
										className='flex flex-row gap-1 items-center bg-neutral-50 hover:bg-neutral-600 border-l border-neutral-300 hover:text-neutral-50 px-2 py-1 transition-colors duration-200 hover:underline rounded-tr-lg'>
										<BiRightArrowAlt className='text-lg' />
									</Link>
								</div>

								<div className='flex grow items-center justify-between p-4 border border-neutral-300 rounded-b-lg'>
									<div className='flex flex-col'>
										<span className='text-2xl font-semibold text-neutral-500 mb-1'>{totalCategories}</span>
										<span className='text-xs font-medium text-[#cd664d]'>{totalCategories} Aprobados</span>
									</div>

									<div className='flex items-center text-sm font-medium text-neutral-400 p-2'>
										<BiArchive className='hi-outline hi-server inline-block size-10' />
									</div>
								</div>
							</div>
						</div>

						<div className=' mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-12 lg:gap-8'>
							<div className='col-span-12 md:col-span-6 xl:col-span-6'>
								<div className='flex items-center justify-between gap-2 text-sm bg-white border border-neutral-300 text-neutral-500 pl-4 rounded-t-lg border-b-transparent'>
									<div className='flex flex-row items-center gap-2 font-medium'>
										<span className='text-xs font-semibold uppercase text-neutral-500'>Historial</span>
									</div>

									<Link
										to='/dashboard/historial'
										className='flex flex-row gap-1 items-center bg-neutral-50 hover:bg-neutral-600 border-l border-neutral-300 hover:text-neutral-50 px-3 py-1.5 transition-colors duration-200 hover:underline rounded-tr-lg'>
										<BiRightArrowAlt className='text-lg' />
									</Link>
								</div>

								<div className='bg-white lg:grid-cols-2 w-auto text-neutral-600 border border-neutral-300 rounded-b-lg'>
									<div className='flex flex-col'>
										<div className='grid grid-cols-1 gap-6 px-4 py-3'>
											<div>
												{Object.entries(groupMovementsByTargetType()).map(([date, groupedMovements]) => (
													<div key={date}>
														<div className='my-2'>
															<h3 className='text-xs font-semibold uppercase text-neutral-400'>{date}</h3>
														</div>

														{groupedMovements.map((movement, index) => (
															<div key={index} className='flex gap-x-1'>
																<div className='relative last:after:hidden after:absolute after:top-7 after:bottom-0 after:start-3.5 after:w-px after:-translate-x-[0.5px] after:bg-neutral-400 '>
																	<div className='relative z-10 size-7 flex justify-center items-center'>
																		<div className='size-2 bg-neutral-400'></div>
																	</div>
																</div>

																<div className='grow pt-0.5 pb-4 mt-1'>
																	<h1 className='text-neutral-500 text-xs mb-1'>{formatDate(movement.createdAt)}</h1>
																	<h3 className='text-neutral-600 text-sm'>
																		{movement.action} {movement.targetName}
																	</h3>
																</div>
															</div>
														))}
													</div>
												))}
											</div>
										</div>
									</div>
								</div>
							</div>

							<div className='col-span-12 md:col-span-6 xl:col-span-6'>
								<div className='flex items-center justify-between gap-2 text-sm bg-white border border-neutral-300 text-neutral-500 pl-4 rounded-t-lg border-b-transparent'>
									<div className='flex flex-row items-center gap-2 font-medium'>
										<span className='text-xs font-semibold uppercase text-neutral-500'>Historial</span>
									</div>

									<Link
										to='/dashboard/historial'
										className='flex flex-row gap-1 items-center bg-neutral-50 hover:bg-neutral-600 border-l border-neutral-300 hover:text-neutral-50 px-3 py-1.5 transition-colors duration-200 hover:underline rounded-tr-lg'>
										<BiRightArrowAlt className='text-lg' />
									</Link>
								</div>

								<div className='bg-white lg:grid-cols-2 w-auto text-neutral-600 border border-neutral-300 rounded-b-lg'>
									<div className='flex flex-col'>
										<div className='grid grid-cols-1 gap-6 px-4 py-3'>
											<div>
												{Object.entries(groupMovementsByTargetType()).map(([date, groupedMovements]) => (
													<div key={date}>
														<div className='my-2'>
															<h3 className='text-xs font-semibold uppercase text-neutral-400'>{date}</h3>
														</div>

														{groupedMovements.map((movement, index) => (
															<div key={index} className='flex gap-x-1'>
																<div className='relative last:after:hidden after:absolute after:top-7 after:bottom-0 after:start-3.5 after:w-px after:-translate-x-[0.5px] after:bg-neutral-400 '>
																	<div className='relative z-10 size-7 flex justify-center items-center'>
																		<div className='size-2 bg-neutral-400'></div>
																	</div>
																</div>

																<div className='grow pt-0.5 pb-4 mt-1'>
																	<h1 className='text-neutral-500 text-xs mb-1'>{formatDate(movement.createdAt)}</h1>
																	<h3 className='text-neutral-600 text-sm'>
																		{movement.action} {movement.targetName}
																	</h3>
																</div>
															</div>
														))}
													</div>
												))}
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</main>
			</div>
		</>
	)
}

export { DashboardPage }

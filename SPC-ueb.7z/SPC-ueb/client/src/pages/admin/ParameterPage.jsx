import { Toaster, toast } from 'sonner'
import { useEffect, useState } from 'react'
import Navbar from '../../components/Navbar'
import { formatDate } from '../../utils/dataFormater.utils'
import { Sub_header } from '../../components/ui/Sub_header.UI'
import { SearchInput } from '../../components/ui/Search_Input.UI'
import { fetch as fetchDefault } from '../../services/api/parameter.api'
import { BiCalendarAlt, BiEditAlt, BiPlus, BiTrashAlt } from 'react-icons/bi'
import { ModalCreate, ModalUpdate, ModalRemove } from '../../components/form/FormsParameter'

const ParameterPage = () => {
	const [parameters, setParameters] = useState([])
	const [showCreateModal, setShowCreateModal] = useState(false)
	const [showUpdateModal, setShowUpdateModal] = useState(false)
	const [showDeleteModal, setShowDeleteModal] = useState(false)
	const [selected, setSelected] = useState(null)
	const [toDelete, setToDelete] = useState(null)
	const [searchTerm, setSearchTerm] = useState('')

	useEffect(() => {
		fetchArticleDefaults()
	}, [])

	const fetchArticleDefaults = async () => {
		try {
			const data = await fetchDefault()
			setParameters(data)
		} catch (error) {
			toast.error('Error al cargar parametros.')
		}
	}

	const handleAdd = () => {
		setShowCreateModal(true)
	}

	const toggleCreateModal = () => {
		setShowCreateModal(!showCreateModal)
	}

	const handleCreateCallback = async () => {
		try {
			await fetchArticleDefaults()
		} catch (error) {
			toast.error('Error al cargar parametros.')
		}
	}

	const handleUpdate = parameter => {
		setSelected(parameter)
		setShowUpdateModal(true)
	}

	const toggleUpdateModal = () => {
		setShowUpdateModal(!showUpdateModal)
	}

	const handleUpdateCallback = async () => {
		try {
			await fetchArticleDefaults()
		} catch (error) {
			toast.error('Error al cargar parametros.')
		}
	}

	const handleDelete = parameter => {
		setToDelete(parameter)
		setShowDeleteModal(true)
	}

	const toggleDeleteModal = () => {
		setShowDeleteModal(!showDeleteModal)
	}

	const handleDeleteCallback = async () => {
		try {
			await fetchArticleDefaults()
		} catch (error) {
			toast.error('Error al cargar parametros.')
		}
	}

	const filtered_parameter = parameters.filter(parameter =>
		parameter.name.toLowerCase().includes(searchTerm.toLowerCase())
	)

	return (
		<>
			<Navbar />

			<div className='h-screen lg:end-0 lg:start-0 lg:top-0 lg:h-20'>
				<main className='container mx-auto px-4 lg:px-8 xl:max-w-7xl'>
					<div className='md:py-2 lg:py-20 transform transition-all'>
						<Sub_header title='Parámetros globales' itemCount={parameters.length} />

						<div className='flex items-center justify-between gap-2 text-md bg-white text-neutral-500 py-3'>
							<div className='flex gap-4'>
								<div
									onClick={handleAdd}
									className='flex flex-row items-center text-sm gap-1 px-2.5 py-2 rounded-lg bg-neutral-600 text-neutral-50 cursor-pointer hover:bg-neutral-700 transition-colors duration-150'>
									<BiPlus />
								</div>
							</div>

							<div className='flex gap-4'>
								<SearchInput onSearch={setSearchTerm} />
							</div>
						</div>

						<div className='grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-12 lg:gap-x-8'>
							{filtered_parameter.map((parameter, index) => (
								<div key={index} className='flex flex-col bg-white active:border-neutral-300 lg:col-span-3'>
									<div className='flex items-center justify-between gap-2 text-sm bg-white border border-b-transparent border-neutral-300 text-neutral-500 pl-4 rounded-t-lg'>
										<p className='text-sm text-gray-500'>
											{parameter === parameter.id_articleDefault ? (
												<input
													type='text'
													value={parameter.name_default}
													onChange={e =>
														setParameters(prevDefaults =>
															prevDefaults.map(item =>
																item.id_articleDefault === parameter.id_articleDefault
																	? { ...item, name: e.target.value }
																	: item
															)
														)
													}
												/>
											) : (
												<span className='font-semibold'>{parameter.name}</span>
											)}
										</p>

										<div>
											<ul className='flex flex-row text-neutral-500'>
												<li
													onClick={() => {
														handleUpdate(parameter)
													}}
													className='border-l border-neutral-300 cursor-pointer'>
													<span className='hover:text-neutral-50 hover:bg-neutral-600 flex items-center gap-2 transition-colors duration-200 p-2'>
														<BiEditAlt className='text-base' />
													</span>
												</li>

												<li
													onClick={() => {
														handleDelete(parameter)
													}}
													className='border-l border-neutral-300 cursor-pointer'>
													<span className='hover:text-neutral-50 flex items-center gap-2 transition-colors duration-200 p-2 hover:bg-[#cd664d] rounded-tr-lg'>
														<BiTrashAlt className='text-base' />
													</span>
												</li>
											</ul>
										</div>
									</div>

									<div className='flex grow items-center justify-between p-4 border border-neutral-300 rounded-b-lg'>
										<div className='flex flex-col gap-2 text-xs font-medium text-neutral-500'>
											<div className='flex flex-row items-center gap-1'>
												<BiCalendarAlt />
												<span>{formatDate(parameter.updatedAt)}</span>
											</div>
										</div>
									</div>
								</div>
							))}
						</div>
					</div>
				</main>
			</div>

			{showCreateModal && (
				<ModalCreate parameter={selected} onClose={toggleCreateModal} onCreate={handleCreateCallback} />
			)}

			{showUpdateModal && (
				<ModalUpdate parameter={selected} onClose={toggleUpdateModal} onUpdate={handleUpdateCallback} />
			)}

			{showDeleteModal && (
				<ModalRemove parameter={toDelete} onClose={toggleDeleteModal} onRemove={handleDeleteCallback} />
			)}

			<Toaster richColors expand={true} />
		</>
	)
}

export { ParameterPage }
